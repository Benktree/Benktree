import numpy as np

class ConditionalProbabilitySampler:
    # Internal p_values and precomputed variables
    _p_values = [0.08, 0.12, 0.15, 0.12, 0.08, 0.06, 0.05, 0.05, 0.05,
                 0.04, 0.04, 0.03, 0.03, 0.03, 0.02, 0.02, 0.02, 0.01]
    _m = len(_p_values)
    _cumulative_p = np.cumsum(_p_values)
    _cutpoints = None

    @classmethod
    def _compute_cutpoints(cls):
        if cls._cutpoints is not None:
            return cls._cutpoints

        cutpoints = []
        j, k, A = 0, 0, 0
        while j < cls._m:
            while A <= j and k < len(cls._cumulative_p):
                A = cls._m * cls._cumulative_p[k]
                k += 1
            j += 1
            cutpoints.append(k)
        cls._cutpoints = cutpoints
        return cutpoints

    @classmethod
    def generate_package_space(cls):
        # Ensure cutpoints are computed
        cls._compute_cutpoints()

        # Algorithm CM to generate a single sample
        U = np.random.uniform(0, 1)
        L = int(cls._m * U) + 1
        X = cls._cutpoints[L - 1]
        while U > cls._cumulative_p[X - 1]:
            X += 1
        return X
