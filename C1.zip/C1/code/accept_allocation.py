from simulator import Simulator
from datetime import datetime, timedelta
import numpy as np


def locker_size(X):
    if 0 <= X <= 3:
        return 'XS'
    elif 4 <= X <= 6:
        return 'S'
    elif 7 <= X <= 12:
        return 'M'
    elif 13 <= X <= 18:
        return 'L'
    else:
        return None


# Set time range
start_time = datetime(2024, 1, 1, 0, 0)
end_time = datetime(2029, 1, 1, 0, 0)

# Initialize current time
current_time = start_time

# Initialize locker demand dictionary
locker_demand = {'XS': 0, 'S': 0, 'M': 0, 'L': 0}  # Added 'XS'

# Record max locker demand and corresponding time
max_locker_demand = {'XS': 0, 'S': 0, 'M': 0, 'L': 0}  # Added 'XS'
max_demand_time = {'XS': None, 'S': None, 'M': None, 'L': None}  # Added 'XS'

# Record pickup times for lockers to release
active_lockers = {'XS': [], 'S': [], 'M': [], 'L': []}

# Define locker capacities
locker_capacity = {'XS': 15, 'S': 22, 'M': 32, 'L': 30}

# Initialize total demands and rejects
total_demands = 0
total_rejects = 0

# Initialize total utilization hours per locker size
total_utilization_hours = {'XS': 0, 'S': 0, 'M': 0, 'L': 0}  # Added 'XS'

# Initialize four-month period utilization, demands, and rejects
period_utilization = {'XS': {}, 'S': {}, 'M': {}, 'L': {}}  # Added 'XS'
period_demands = {}
period_rejects = {}
period_hours = {}

# Initialize yearly utilization and rejects per size
yearly_utilization_hours = {'XS': {}, 'S': {}, 'M': {}, 'L': {}}  # Added 'XS'
yearly_hours = {}
yearly_total_demands = {}
yearly_total_rejects = {}
yearly_rejects_per_size = {}  # New dictionary to record rejects per size per year

# Initialize total hours
total_hours = 0

# Initialize daily utilization tracking
current_day = start_time.date()
daily_utilization_hours = {'XS': 0, 'S': 0, 'M': 0, 'L': 0}
hours_passed_today = 0

yearly_demand = [50000, 60000, 60000, 60000, 60000]
# yearly_demand = Simulator.generate_five_year_demand()
print(yearly_demand)

while current_time < end_time:
    # Check if day has changed
    if current_time.date() != current_day:
        # Day has changed, print yesterday's utilization
        print(f'\nUtilization for {current_day}:')
        for size in ['XS', 'S', 'M', 'L']:
            total_available_hours = locker_capacity[size] * hours_passed_today
            utilization = daily_utilization_hours[size] / total_available_hours if total_available_hours > 0 else 0
            print(f'  {size} Utilization: {utilization * 100:.2f}%')
        # Reset daily tracking variables
        daily_utilization_hours = {'XS': 0, 'S': 0, 'M': 0, 'L': 0}
        hours_passed_today = 0
        current_day = current_time.date()

    # Increment hours passed today
    hours_passed_today += 1

    # Get four-month period key
    period = ((current_time.month - 1) // 4) + 1  # Periods 1, 2, 3
    period_key = (current_time.year, period)
    year = current_time.year

    # Accumulate period hours
    if period_key not in period_hours:
        period_hours[period_key] = 0
    period_hours[period_key] += 1

    # Accumulate yearly hours
    if year not in yearly_hours:
        yearly_hours[year] = 0
    yearly_hours[year] += 1

    # Accumulate total hours
    total_hours += 1

    # Generate hourly demand
    demand_hourly = Simulator.generate_hourly_demand(current_time, yearly_demand)
    print(f'\nCurrent time: {current_time}')
    print(f'Hourly Demand: {demand_hourly}')

    # Process each demand
    for _ in range(demand_hourly):
        X = Simulator.generate_package_space()
        size = locker_size(X)

        total_demands += 1

        # Initialize period demands and rejects
        if period_key not in period_demands:
            period_demands[period_key] = 0
        if period_key not in period_rejects:
            period_rejects[period_key] = 0

        # Initialize yearly demands and rejects
        if year not in yearly_total_demands:
            yearly_total_demands[year] = 0
        if year not in yearly_total_rejects:
            yearly_total_rejects[year] = 0

        # Initialize yearly rejects per size
        if year not in yearly_rejects_per_size:
            yearly_rejects_per_size[year] = {'XS': 0, 'S': 0, 'M': 0, 'L': 0}  # Added 'XS'

        period_demands[period_key] += 1
        yearly_total_demands[year] += 1

        allocation = None

        # Implement Strawman Heuristic with 'XS' locker
        if size == 'XS':
            # Try to allocate an 'XS' locker
            if locker_demand['XS'] < locker_capacity['XS']:
                allocation = 'XS'
            elif locker_demand['S'] < locker_capacity['S']:
                allocation = 'S'
            elif locker_demand['M'] < locker_capacity['M']:
                allocation = 'M'
            elif locker_demand['L'] < locker_capacity['L']:
                allocation = 'L'
        elif size == 'S':
            # Try to allocate an 'S' locker
            if locker_demand['S'] < locker_capacity['S']:
                allocation = 'S'
            elif locker_demand['M'] < locker_capacity['M']:
                allocation = 'M'
            elif locker_demand['L'] < locker_capacity['L']:
                allocation = 'L'
        elif size == 'M':
            # Try to allocate an 'M' locker
            if locker_demand['M'] < locker_capacity['M']:
                allocation = 'M'
            elif locker_demand['L'] < locker_capacity['L']:
                allocation = 'L'
        elif size == 'L':
            # Try to allocate an 'L' locker
            if locker_demand['L'] < locker_capacity['L']:
                allocation = 'L'

        if allocation:
            # Assign locker
            locker_demand[allocation] += 1

            # Update max demand and its time
            if locker_demand[allocation] > max_locker_demand[allocation]:
                max_locker_demand[allocation] = locker_demand[allocation]
                max_demand_time[allocation] = current_time

            # Generate corresponding pickup time and record
            pickup_time = Simulator.generate_pickup_time(current_time)
            active_lockers[allocation].append(pickup_time)
            print(f'{allocation} Locker assigned to package of size {size}, Pickup Time: {pickup_time}')
        else:
            # Reject the request
            total_rejects += 1
            period_rejects[period_key] += 1
            yearly_total_rejects[year] += 1

            # Record reject per size
            if size in yearly_rejects_per_size[year]:
                yearly_rejects_per_size[year][size] += 1
            else:
                yearly_rejects_per_size[year][size] = 1

            print(f'Package of size {size} rejected at {current_time}')

    # Release lockers whose pickup time has arrived
    for size in ['XS', 'S', 'M', 'L']:  # Added 'XS'
        active_lockers[size] = [pt for pt in active_lockers[size] if pt > current_time]
        lockers_released = locker_demand[size] - len(active_lockers[size])
        locker_demand[size] -= lockers_released  # Update current demand

    # Calculate and accumulate utilization
    for size in ['XS', 'S', 'M', 'L']:  # Added 'XS'
        # Accumulate period utilization
        if period_key not in period_utilization[size]:
            period_utilization[size][period_key] = 0
        period_utilization[size][period_key] += locker_demand[size]

        # Accumulate yearly utilization
        if year not in yearly_utilization_hours[size]:
            yearly_utilization_hours[size][year] = 0
        yearly_utilization_hours[size][year] += locker_demand[size]

        # Accumulate total utilization hours
        total_utilization_hours[size] += locker_demand[size]

    # Update daily utilization
    for size in ['XS', 'S', 'M', 'L']:  # Added 'XS'
        daily_utilization_hours[size] += locker_demand[size]

    # Print current hour's locker demand and utilization
    print(f'Current locker demand: XS={locker_demand["XS"]}, S={locker_demand["S"]}, M={locker_demand["M"]}, L={locker_demand["L"]}')

    # Calculate and print hourly utilization
    print('Hourly Utilization:')
    for size in ['XS', 'S', 'M', 'L']:  # Added 'XS'
        hourly_utilization = locker_demand[size] / locker_capacity[size]
        print(f'  {size}: {hourly_utilization * 100:.2f}%')

    # Optionally, print current utilization up to this hour
    print(f'Utilization up to {current_time}:')
    for size in ['XS', 'S', 'M', 'L']:
        total_available_hours = locker_capacity[size] * hours_passed_today
        utilization = daily_utilization_hours[size] / total_available_hours if total_available_hours > 0 else 0
        print(f'  {size} Utilization: {utilization * 100:.2f}%')

    # Move to the next hour
    current_time += timedelta(hours=1)

# After the loop, print the utilization for the last day
print(f'\nUtilization for {current_day}:')
for size in ['XS', 'S', 'M', 'L']:
    total_available_hours = locker_capacity[size] * hours_passed_today
    utilization = daily_utilization_hours[size] / total_available_hours if total_available_hours > 0 else 0
    print(f'  {size} Utilization: {utilization * 100:.2f}%')

# Calculate average utilization
average_utilization = {}
for size in ['XS', 'S', 'M', 'L']:  # Added 'XS'
    average_utilization[size] = total_utilization_hours[size] / (locker_capacity[size] * total_hours)

# Calculate service level
service_level = (total_demands - total_rejects) / total_demands if total_demands > 0 else 0

# Print final results
print("\nMaximum Locker Demand and Corresponding Times:")
print(f"XS: {max_locker_demand['XS']} at {max_demand_time['XS']}, "
      f"S: {max_locker_demand['S']} at {max_demand_time['S']}, "
      f"M: {max_locker_demand['M']} at {max_demand_time['M']}, "
      f"L: {max_locker_demand['L']} at {max_demand_time['L']}")

print("\nAverage Utilization:")
for size in ['XS', 'S', 'M', 'L']:  # Added 'XS'
    print(f"{size}: {average_utilization[size]*100:.2f}%")

print(f"\nTotal Demands: {total_demands}")
print(f"Total Rejects: {total_rejects}")
print(f"Service Level: {service_level*100:.2f}%")

# Calculate and print four-month period average utilization and service level
print("\nFour-Month Period Average Utilization and Service Level:")
for period_key in sorted(period_hours.keys()):
    print(f"Period: {period_key[0]} - Quadrimester {period_key[1]}")
    for size in ['XS', 'S', 'M', 'L']:  # Added 'XS'
        if period_key in period_utilization[size]:
            avg_util = period_utilization[size][period_key] / (locker_capacity[size] * period_hours[period_key])
            print(f"  {size} Average Utilization: {avg_util*100:.2f}%")
    if period_key in period_demands:
        period_demands_count = period_demands[period_key]
        period_rejects_count = period_rejects.get(period_key, 0)
        period_service_level = (period_demands_count - period_rejects_count) / period_demands_count if period_demands_count > 0 else 0
        print(f"  Service Level: {period_service_level*100:.2f}%")

# Calculate and print yearly utilization and rejects per size for 2024 to 2028
print("\nYearly Utilization and Rejects from 2024 to 2028:")
for year in range(2024, 2029):
    if year in yearly_hours:
        print(f"\nYear: {year}")
        for size in ['XS', 'S', 'M', 'L']:  # Added 'XS'
            if year in yearly_utilization_hours[size]:
                yearly_util = yearly_utilization_hours[size][year] / (locker_capacity[size] * yearly_hours[year])
                print(f"  {size} Average Utilization: {yearly_util*100:.2f}%")
        # Yearly service level
        year_demands = yearly_total_demands.get(year, 0)
        year_rejects = yearly_total_rejects.get(year, 0)
        year_service_level = (year_demands - year_rejects) / year_demands if year_demands > 0 else 0
        print(f"  Service Level: {year_service_level*100:.2f}%")

        # Print rejects per size
        rejects_per_size = yearly_rejects_per_size.get(year, {'XS': 0, 'S': 0, 'M': 0, 'L': 0})  # Added 'XS'
        print(f"  Rejects per Size: {rejects_per_size}")
