from simulator import Simulator
from datetime import datetime, timedelta
import numpy as np


def locker_size(X):
    if 0 <= X <= 3:
        return 'XS'
    elif 4 <= X <= 6:
        return 'S'
    elif 7 <= X <= 12:
        return 'M'
    elif 13 <= X <= 18:
        return 'L'
    else:
        return None


# 设置时间范围
start_time = datetime(2024, 1, 1, 0, 0)
end_time = datetime(2029, 1, 1, 0, 0)

# 初始化当前时间
current_time = start_time

# 初始化字典记录各尺寸 locker 的需求数量
locker_demand = {'XS': 0, 'S': 0, 'M': 0, 'L': 0}
# 用于记录每个尺寸 locker 的最大需求量和对应时间
max_locker_demand = {'XS': 0, 'S': 0, 'M': 0, 'L': 0}
max_demand_time = {'XS': None, 'S': None, 'M': None, 'L': None}

# 用于记录每个 locker 的 pickup time 以便释放
active_lockers = {'XS': [], 'S': [], 'M': [], 'L': []}

# 定义 locker 容量
locker_capacity = {'XS': 12, 'S': 40, 'M': 37, 'L': 52}

# 初始化每日利用率跟踪变量
current_day = start_time.date()
daily_utilization_hours = {'XS': 0, 'S': 0, 'M': 0, 'L': 0}
hours_passed_today = 0

yearly_demand = [50000, 60000, 60000, 60000, 60000]


while current_time < end_time:
    # 检查日期是否改变
    if current_time.date() != current_day:
        # 日期已改变，打印前一天的利用率
        print(f'\nUtilization for {current_day}:')
        for size in ['XS', 'S', 'M', 'L']:
            total_available_hours = locker_capacity[size] * hours_passed_today
            utilization = daily_utilization_hours[size] / total_available_hours if total_available_hours > 0 else 0
            print(f'  {size} Utilization: {utilization * 100:.2f}%')
        # 重置每日利用率跟踪变量
        daily_utilization_hours = {'XS': 0, 'S': 0, 'M': 0, 'L': 0}
        hours_passed_today = 0
        current_day = current_time.date()

    # 增加当天已过的小时数
    hours_passed_today += 1

    # 生成每小时需求量
    demand_hourly = Simulator.generate_hourly_demand(current_time, yearly_demand)
    print(f'\nCurrent time: {current_time}')
    print(f'Hourly Demand: {demand_hourly}')

    # 按小时生成每个需求的 package space 和 pickup time
    for _ in range(demand_hourly):
        X = Simulator.generate_package_space()
        size = locker_size(X)

        if size:
            locker_demand[size] += 1

            # 更新最大需求及其时间
            if locker_demand[size] > max_locker_demand[size]:
                max_locker_demand[size] = locker_demand[size]
                max_demand_time[size] = current_time

            # 生成对应的 pickup time 并记录
            pickup_time = Simulator.generate_pickup_time(current_time)
            active_lockers[size].append(pickup_time)
            print(f'{size} Locker Assigned, Pickup Time: {pickup_time}')

    # 检查是否有 lockers 到达 pickup time 并释放
    for size in ['XS', 'S', 'M', 'L']:
        active_lockers[size] = [pt for pt in active_lockers[size] if pt > current_time]
        lockers_released = locker_demand[size] - len(active_lockers[size])
        locker_demand[size] -= lockers_released  # 更新当前需求

    # 更新每日利用率
    for size in ['XS', 'S', 'M', 'L']:
        daily_utilization_hours[size] += locker_demand[size]

    # 计算并打印当前时间的利用率
    print(f'Utilization up to {current_time}:')
    for size in ['XS', 'S', 'M', 'L']:
        total_available_hours = locker_capacity[size] * hours_passed_today
        utilization = daily_utilization_hours[size] / total_available_hours if total_available_hours > 0 else 0
        print(f'  {size} Utilization: {utilization * 100:.2f}%')

    # 打印当前小时的 locker 需求
    print(
        f'Locker Demand at {current_time}: XS={locker_demand["XS"]}, S={locker_demand["S"]}, M={locker_demand["M"]}, L={locker_demand["L"]}')
    print(f'Max Locker Demand so far:')
    for size in ['XS', 'S', 'M', 'L']:
        print(f'  {size}={max_locker_demand[size]} (at {max_demand_time[size]})')

    # 进入下一小时
    current_time += timedelta(hours=1)

# 打印最后一天的利用率
print(f'\nUtilization for {current_day}:')
for size in ['XS', 'S', 'M', 'L']:
    total_available_hours = locker_capacity[size] * hours_passed_today
    utilization = daily_utilization_hours[size] / total_available_hours if total_available_hours > 0 else 0
    print(f'  {size} Utilization: {utilization * 100:.2f}%')

# 打印整个时间段内最大需求的结果及其时间点
print("\nFinal Maximum Locker Demand and Times:")
for size in ['XS', 'S', 'M', 'L']:
    print(f'{size}: {max_locker_demand[size]} at {max_demand_time[size]}')
