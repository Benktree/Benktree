import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches


def generate_region_specs(module_information, module_list, module_width=1.0, x_start=0):
    region_specs = []
    locker_sizes = []
    x = x_start

    xs = 0.23
    s = 0.46
    m = 0.92
    l = 1.38
    screen = 1.38

    height_to_size = {
        xs: 'XS',
        s: 'S',
        m: 'M',
        l: 'L',
        screen: 'L',
    }

    for module_id in module_list:
        if module_id not in module_information:
            raise ValueError(f"Module ID {module_id} not found in module_information.")
        heights = module_information[module_id]
        y = 0
        for height in heights:
            region_specs.append((x, y, module_width, height))
            size = None
            for h, s_name in height_to_size.items():
                if abs(height - h) < 1e-6:
                    size = s_name
                    break
            if size is None:
                size = 'Unknown'
            locker_sizes.append(size)
            y += height
        x += module_width
    return region_specs, locker_sizes


def create_animation(region_specs, locker_sizes, utilization_per_year):
    n_regions = len(region_specs)
    n_frames = len(utilization_per_year)

    utilization_data = []
    for year_utilization in utilization_per_year:
        utilization_per_cell = []
        for size in locker_sizes:
            utilization = year_utilization.get(size, 0)
            utilization_per_cell.append(utilization)
        utilization_data.append(utilization_per_cell)

    fig, ax = plt.subplots(figsize=(15, 8))

    x_values = [x for (x, y, w, h) in region_specs]
    widths = [w for (x, y, w, h) in region_specs]
    x_min = min(x_values)
    x_max = max([x + w for x, w in zip(x_values, widths)])

    module_heights = {}
    for idx, (x, y, w, h) in enumerate(region_specs):
        if x not in module_heights:
            module_heights[x] = 0
        module_heights[x] += h

    y_max = max(module_heights.values())
    y_min = 0

    ax.set_xlim(x_min - module_width / 2, x_max + module_width / 2)
    ax.set_ylim(y_min, y_max + 0.5)
    ax.axis('off')

    patches_list = []
    for x, y, width, height in region_specs:
        rect = patches.Rectangle(
            (x, y),
            width,
            height,
            linewidth=0.5,
            edgecolor='black',
            facecolor='gray',
            alpha=0.5
        )
        patches_list.append(rect)
        ax.add_patch(rect)

    def update(frame):
        utilizations = utilization_data[frame]
        for rect, utilization in zip(patches_list, utilizations):
            rect.set_facecolor(plt.cm.coolwarm(utilization))
            rect.set_alpha(1.0)
        year_text.set_text(f"Year {frame + 1}")
        return patches_list + [year_text]

    year_text = ax.text((x_min + x_max) / 2, y_max + 0.2, '', ha='center', fontsize=16)

    sm = plt.cm.ScalarMappable(cmap=plt.cm.coolwarm, norm=plt.Normalize(0, 1))
    sm.set_array([])
    cbar = plt.colorbar(sm, ax=ax, orientation='horizontal', pad=0.1)
    cbar.set_label('Utilization')

    ani = animation.FuncAnimation(
        fig,
        update,
        frames=n_frames,
        interval=1000,
        blit=True
    )

    plt.show()


module_width = 1.3

xs = 0.23
s = 0.46
m = 0.92
l = 1.38
screen = 1.38

module_information = {
    1: [l, l, s, s, s, s, s, s, l],
    2: [l, m, screen, m, s, s, l],
    3: [l, l, m, m, xs, xs, m, m],
    4: [l, m, s, m, m, s, s, l],
}

module_list = [1, 1, 2, 3, 1, 1, 4, 3, 3, 1, 1, 4, 3, 3, 1, 1, 4, 3, 2, 1, 1]

region_specs, locker_sizes = generate_region_specs(module_information, module_list, module_width)

utilization_per_year = [
    {'XS': 0.6225, 'S': 0.1802, 'M': 0.2378, 'L': 0.0865},
    {'XS': 0.6607, 'S': 0.2218, 'M': 0.2781, 'L': 0.1051},
    {'XS': 0.6787, 'S': 0.2493, 'M': 0.3038, 'L': 0.1197},
    {'XS': 0.6902, 'S': 0.2661, 'M': 0.3196, 'L': 0.1292},
    {'XS': 0.6822, 'S': 0.2639, 'M': 0.3165, 'L': 0.1323}
]

create_animation(region_specs, locker_sizes, utilization_per_year)
