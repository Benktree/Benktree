import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta


class Simulator:
    # Internal probability values for package space sampling
    _p_values = [0.08, 0.12, 0.15, 0.12, 0.08, 0.06, 0.05, 0.05, 0.05,
                 0.04, 0.04, 0.03, 0.03, 0.03, 0.02, 0.02, 0.02, 0.01]
    _m = len(_p_values)
    _cumulative_p = np.cumsum(_p_values)
    _cutpoints = None

    # Conditional demand scenarios
    _demand_scenarios = {
        1: {None: [(50000, 0.25), (60000, 0.25), (80000, 0.5)]},  # Initial year
        2: {
            50000: [(60000, 0.3), (65000, 0.4), (70000, 0.3)],
            60000: [(65000, 0.6), (70000, 0.4)],
            80000: [(90000, 0.6), (100000, 0.4)],
        },
        3: {
            60000: [(60000, 0.5), (70000, 0.5)],
            65000: [(60000, 0.3), (70000, 0.4), (75000, 0.3)],
            70000: [(70000, 0.6), (75000, 0.4)],
            90000: [(100000, 0.6), (110000, 0.4)],
            100000: [(100000, 0.4), (110000, 0.6)],
        },
        4: {
            60000: [(60000, 0.5), (75000, 0.5)],
            70000: [(60000, 0.3), (75000, 0.4), (80000, 0.3)],
            75000: [(75000, 0.6), (80000, 0.4)],
            100000: [(80000, 0.1), (105000, 0.6), (120000, 0.3)],
            110000: [(105000, 0.4), (120000, 0.6)],
        },
        5: {
            60000: [(60000, 0.5), (65000, 0.5)],
            75000: [(60000, 0.3), (65000, 0.4), (90000, 0.3)],
            80000: [(65000, 0.6), (90000, 0.4)],
            105000: [(90000, 0.25), (110000, 0.75)],
            120000: [(110000, 0.4), (150000, 0.6)],
        },
    }

    # Load probability matrix from Excel file
    file_path = 'D:/pythonproject/caculate/Casework 4/duration.xlsx'
    duration_df = pd.read_excel(file_path, sheet_name='Sheet1', header=None, engine='openpyxl')

    # Clean the DataFrame by setting proper column names
    duration_df.columns = [f'Hour_{i}' for i in range(len(duration_df.columns))]

    # Drop irrelevant rows/columns (if there are extra headers or empty rows at the beginning)
    duration_df = duration_df.drop([0]).reset_index(drop=True)
    duration_df = duration_df.drop(duration_df.columns[0], axis=1)

    # Extract the probability matrix and normalize it if it's in a scaled format
    probability_matrix = duration_df.iloc[:, :24].astype(float).values
    probability_matrix = probability_matrix / 10000  # Assuming data is in X10,000 format to convert to probabilities

    @classmethod
    def _compute_cutpoints(cls):
        if cls._cutpoints is not None:
            return cls._cutpoints

        cutpoints = []
        j, k, A = 0, 0, 0
        while j < cls._m:
            while A <= j and k < len(cls._cumulative_p):
                A = cls._m * cls._cumulative_p[k]
                k += 1
            j += 1
            cutpoints.append(k)
        cls._cutpoints = cutpoints
        return cutpoints

    @classmethod
    def generate_package_space(cls):
        # Ensure cutpoints are computed
        cls._compute_cutpoints()

        # Algorithm CM to generate a single sample
        U = np.random.uniform(0, 1)
        L = int(cls._m * U) + 1
        X = cls._cutpoints[L - 1]
        while U > cls._cumulative_p[X - 1]:
            X += 1
        return X


    @classmethod
    def generate_five_year_demand(cls):
        # Generate demand for 5 years based on conditional probabilities
        demand = []
        previous_demand = None

        for year in range(1, 6):
            year_scenarios = cls._demand_scenarios[year][previous_demand]
            year_demand = cls._select_demand(year_scenarios)
            demand.append(year_demand)
            previous_demand = year_demand  # Update for the next year's conditional probabilities

        return demand

    @staticmethod
    def _select_demand(scenarios):
        demands, probabilities = zip(*scenarios)
        return random.choices(demands, weights=probabilities, k=1)[0]


    @classmethod
    def _generate_demand_shared(cls, input_datetime, five_year_demand):
        """
        Shared method to generate demand components based on input datetime.

        Args:
        input_datetime (datetime): The input datetime (precise to hour).

        Returns:
        tuple: A tuple containing year, yearly demand, four_week_period, weekly_demand, daily_demand, and day_of_week.
        """
        # Define demand share parameters
        four_week_demand_share = [0.06, 0.05, 0.06, 0.07, 0.09, 0.06, 0.04, 0.1, 0.1, 0.06, 0.08, 0.1, 0.13]
        daily_demand_share = [0.1, 0.15, 0.15, 0.18, 0.22, 0.15, 0.05]  # Mon, ..., Sat, Sun
        hourly_demand_share = [
            0.02, 0.02, 0.01, 0.01, 0.03, 0.03, 0.04, 0.04,
            0.06, 0.06, 0.06, 0.06, 0.04, 0.06, 0.08, 0.06,
            0.06, 0.06, 0.05, 0.05, 0.04, 0.02, 0.02, 0.02
        ]


        coefficient_variation_daily = 0.2
        z_995 = 2.576

        # Determine year and corresponding yearly demand
        year = input_datetime.year
        if year < 2024 or year > 2029:
            raise ValueError("Input year must be between 2024 and 2029.")
        yearly_demand = five_year_demand[year - 2024]

        # Determine week of the year and corresponding four-week period demand share
        week_of_year = input_datetime.isocalendar()[1]
        four_week_period = (week_of_year - 1) // 4
        if four_week_period > 12:
            four_week_period = 12
        # max_weekly_demand = yearly_demand * four_week_demand_share[four_week_period] * (1 + z_995 * coefficient_variation_weekly) / 4
        weekly_demand = yearly_demand * four_week_demand_share[four_week_period] / 4

        # Determine day of the week and corresponding daily demand share
        day_of_week = input_datetime.weekday()  # Monday = 0, Sunday = 6
        # max_daily_demand = weekly_demand * daily_demand_share[day_of_week] * (1 + z_995 * coefficient_variation_daily)
        daily_demand_mean = weekly_demand * daily_demand_share[day_of_week]
        daily_demand = np.random.normal(daily_demand_mean,coefficient_variation_daily * daily_demand_mean)

        # Determine hour of the day and corresponding hourly demand share
        hour_of_day = input_datetime.hour
        hourly_demand_share_value = hourly_demand_share[hour_of_day]
        hourly_demand = round(daily_demand * hourly_demand_share_value)

        return year, yearly_demand, four_week_period, weekly_demand, daily_demand, day_of_week, hourly_demand


    @classmethod
    def generate_hourly_demand(cls, input_datetime, five_year_demand):
        """
        Generate daily demand based on input datetime for a period of 5 years (2024-2029).

        Args:
        input_datetime (datetime): The input datetime (precise to hour).

        Returns:
        float: The daily demand for the given input datetime.
        """
        _, _, _, _, _, _, hourly_demand = cls._generate_demand_shared(input_datetime, five_year_demand)
        return hourly_demand

    # @classmethod
    # def daily_demand_details(cls, input_datetime):
    #     """
    #     Generate detailed demand information based on input datetime for a period of 5 years (2024-2029).
    #
    #     Args:
    #     input_datetime (datetime): The input datetime (precise to hour).
    #
    #     Returns:
    #     dict: A dictionary containing detailed demand information for each period.
    #     """
    #     year, yearly_demand, four_week_period, weekly_demand, daily_demand, day_of_week = cls._generate_demand_shared(input_datetime)
    #
    #     return {
    #         "year demand": yearly_demand,
    #         "weekly_demand": weekly_demand,
    #         "daily_demand": daily_demand,
    #         "four_week_period": four_week_period + 1,
    #         "day_of_week": day_of_week
    #     }


    @classmethod
    def generate_pickup_time(cls, deposit_time):
        """
        Generate the pickup datetime based on the deposit datetime.

        Args:
        deposit_time (datetime): The datetime when the deposit was made.

        Returns:
        datetime: The datetime for the pickup time.
        """
        # Parse the deposit hour
        deposit_hour = deposit_time.hour

        # Simulate the pickup hour
        probabilities = cls.probability_matrix[deposit_hour]
        probabilities /= probabilities.sum()  # Ensure the probabilities sum to 1
        pickup_hour = np.random.choice(range(24), p=probabilities)  # Choose a pickup hour based on probabilities

        # Update pickup hour (custom logic)
        if pickup_hour == 23:
            pickup_hour = 0
        else:
            pickup_hour += 1

        # Convert the pickup hour to a datetime object based on the deposit time
        if pickup_hour < deposit_hour:
            pickup_datetime = deposit_time + timedelta(days=1)
        else:
            pickup_datetime = deposit_time

        # Set the correct hour for pickup
        pickup_datetime = pickup_datetime.replace(hour=pickup_hour, minute=0, second=0, microsecond=0)
        return pickup_datetime


