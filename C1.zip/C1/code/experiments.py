from simulator import Simulator
from datetime import datetime, timedelta
import numpy as np

def locker_size(X):
    if 0 <= X <= 6:
        return 'S'
    elif 7 <= X <= 12:
        return 'M'
    elif 13 <= X <= 18:
        return 'L'
    else:
        return None

# Number of simulation runs
n_runs = 5

# Years to simulate
years_to_simulate = range(2024, 2029)

# Dictionaries to collect metrics over runs
average_utilization_over_runs = {year: {'S': 0, 'M': 0, 'L': 0} for year in years_to_simulate}
service_level_over_runs = {year: 0 for year in years_to_simulate}
rejects_per_size_over_runs = {year: {'S': 0, 'M': 0, 'L': 0} for year in years_to_simulate}

# Loop over n_runs
for run in range(n_runs):
    print(f"\nStarting simulation run {run+1}/{n_runs}")

    # Set time range
    start_time = datetime(2024, 1, 1, 0, 0)
    end_time = datetime(2029, 1, 1, 0, 0)

    # Initialize current time
    current_time = start_time

    # Initialize locker demand dictionary
    locker_demand = {'S': 0, 'M': 0, 'L': 0}

    # Record pickup times for lockers to release
    active_lockers = {'S': [], 'M': [], 'L': []}

    # Define locker capacities
    locker_capacity = {'S': 90, 'M': 40, 'L': 50}

    # Initialize total demands and rejects
    total_demands = 0
    total_rejects = 0

    # Initialize yearly utilization and rejects per size
    yearly_utilization_hours = {year: {'S': 0, 'M': 0, 'L': 0} for year in years_to_simulate}
    yearly_hours = {year: 0 for year in years_to_simulate}
    yearly_total_demands = {year: 0 for year in years_to_simulate}
    yearly_total_rejects = {year: 0 for year in years_to_simulate}
    yearly_rejects_per_size = {year: {'S': 0, 'M': 0, 'L': 0} for year in years_to_simulate}

    # Generate yearly demand
    yearly_demand = Simulator.generate_five_year_demand()
    # Optionally, print the generated yearly demand
    # print(yearly_demand)

    while current_time < end_time:
        year = current_time.year

        # Accumulate yearly hours
        yearly_hours[year] += 1

        # Generate hourly demand
        demand_hourly = Simulator.generate_hourly_demand(current_time, yearly_demand)
        # Optionally, print detailed simulation information
        # print(f'\nCurrent time: {current_time}')
        # print(f'Hourly Demand: {demand_hourly}')

        # Process each demand
        for _ in range(demand_hourly):
            X = Simulator.generate_package_space()
            size = locker_size(X)

            total_demands += 1
            yearly_total_demands[year] += 1

            allocation = None

            # Implement Strawman Heuristic
            if size == 'S':
                # Try to allocate an 'S' locker
                if locker_demand['S'] < locker_capacity['S']:
                    allocation = 'S'
                elif locker_demand['M'] < locker_capacity['M']:
                    allocation = 'M'
                elif locker_demand['L'] < locker_capacity['L']:
                    allocation = 'L'
            elif size == 'M':
                # Try to allocate an 'M' locker
                if locker_demand['M'] < locker_capacity['M']:
                    allocation = 'M'
                elif locker_demand['L'] < locker_capacity['L']:
                    allocation = 'L'
            elif size == 'L':
                # Try to allocate an 'L' locker
                if locker_demand['L'] < locker_capacity['L']:
                    allocation = 'L'

            if allocation:
                # Assign locker
                locker_demand[allocation] += 1

                # Generate corresponding pickup time and record
                pickup_time = Simulator.generate_pickup_time(current_time)
                active_lockers[allocation].append(pickup_time)
                # Optionally, print assignment information
                # print(f'{allocation} Locker assigned to package of size {size}, Pickup Time: {pickup_time}')
            else:
                # Reject the request
                total_rejects += 1
                yearly_total_rejects[year] += 1
                yearly_rejects_per_size[year][size] += 1
                # Optionally, print rejection information
                # print(f'Package of size {size} rejected at {current_time}')

        # Release lockers whose pickup time has arrived
        for size in ['S', 'M', 'L']:
            active_lockers[size] = [pt for pt in active_lockers[size] if pt > current_time]
            lockers_released = locker_demand[size] - len(active_lockers[size])
            locker_demand[size] -= lockers_released  # Update current demand

        # Accumulate yearly utilization hours
        for size in ['S', 'M', 'L']:
            yearly_utilization_hours[year][size] += locker_demand[size]

        # Move to the next hour
        current_time += timedelta(hours=1)

    # After each run, collect yearly metrics
    for year in years_to_simulate:
        # Calculate average utilization for each size
        for size in ['S', 'M', 'L']:
            utilization = yearly_utilization_hours[year][size] / (locker_capacity[size] * yearly_hours[year])
            average_utilization_over_runs[year][size] += utilization

        # Calculate service level
        demands = yearly_total_demands[year]
        rejects = yearly_total_rejects[year]
        service_level = (demands - rejects) / demands if demands > 0 else 0
        service_level_over_runs[year] += service_level

        # Accumulate rejects per size
        for size in ['S', 'M', 'L']:
            rejects_size = yearly_rejects_per_size[year][size]
            rejects_per_size_over_runs[year][size] += rejects_size

# After all runs, compute average metrics over runs
for year in years_to_simulate:
    # Average utilization
    for size in ['S', 'M', 'L']:
        average_utilization_over_runs[year][size] /= n_runs

    # Average service level
    service_level_over_runs[year] /= n_runs

    # Average rejects per size
    for size in ['S', 'M', 'L']:
        rejects_per_size_over_runs[year][size] /= n_runs

# Print average metrics over runs per year
print("\nAverage Results over {} Runs:".format(n_runs))
for year in years_to_simulate:
    print(f"\nYear: {year}")
    for size in ['S', 'M', 'L']:
        avg_util = average_utilization_over_runs[year][size] * 100  # Convert to percentage
        print(f"  {size} Average Utilization: {avg_util:.2f}%")
    service_level = service_level_over_runs[year] * 100  # Convert to percentage
    print(f"  Service Level: {service_level:.2f}%")
    rejects_per_size = {size: int(rejects_per_size_over_runs[year][size]) for size in ['S', 'M', 'L']}
    print(f"  Rejects per Size: {rejects_per_size}")
