from simulator import Simulator

from datetime import datetime, timedelta
import numpy as np

# locker number & size 确定
# another_file.py

from Cost import calculate_implement_cost, calculate_ergonomics_cost

def locker_size(X):
    if 0 <= X <= 3:
        return 'XS'
    if 4 <= X <= 6:
        return 'S'
    elif 7 <= X <= 12:
        return 'M'
    elif 13 <= X <= 18:
        return 'L'
    else:
        return None

# Example usage for calculate_ergonomics_cost
locker_info = (0, 3.3, 1.3, 6, 2, 'A')  # Example locker information
size_combo = ('M', 'L')  # Example size combination (package size & locker size)
ergonomics_cost = calculate_ergonomics_cost(locker_info, size_combo)
print(f"The calculated ergonomics cost for size combo {size_combo} is: {ergonomics_cost:.4f}")

# Example usage for calculate_implement_cost
# module_number = [138, 140, 0, 2, 70, 70, 0]  # List of module quantities
module_number = [10, 10, 0, 2, 1, 10, 0]
module_cost = [40, 40, 40, 85, 85, 40, 85]    # Corresponding module costs
H_input = 6  # Height input

total_implement_cost = calculate_implement_cost(H_input, module_number, module_cost)
print(f"When H is {H_input}, the total implementation cost is: {total_implement_cost}")
