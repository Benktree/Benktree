from simulator import Simulator
from datetime import datetime, timedelta
import numpy as np

def locker_size(X):
    # Determine locker size based on package space
    if 0 <= X <= 6:
        return 'S'
    elif 7 <= X <= 12:
        return 'M'
    elif 13 <= X <= 18:
        return 'L'
    else:
        return None

# Set the simulation time range
start_time = datetime(2024, 1, 1, 0, 0)
end_time = datetime(2024, 2, 1, 0, 0)

# Initialize the current time
current_time = start_time

# Initialize a dictionary to record the demand for each locker size
locker_demand = {'S': 0, 'M': 0, 'L': 0}

# Record maximum demand and the corresponding time for each locker size
max_locker_demand = {'S': 0, 'M': 0, 'L': 0}
max_demand_time = {'S': None, 'M': None, 'L': None}

# Track active lockers and their pickup times
active_lockers = {'S': [], 'M': [], 'L': []}

# Generate demand data for five years
yearly_demand = Simulator.generate_five_year_demand()
max_yearly_demand = [80000, 100000, 110000, 120000, 150000]
print(yearly_demand)

while current_time < end_time:
    # Generate daily demand and calculate hourly demand
    demand_hourly = Simulator.generate_hourly_demand(current_time, yearly_demand)
    print(f'Current time: {current_time}')
    print(f'Hourly Demand: {demand_hourly}')

    # Assign lockers for hourly demand
    for _ in range(demand_hourly):
        X = Simulator.generate_package_space()
        size = locker_size(X)

        if size:
            locker_demand[size] += 1

            # Update maximum demand and its timestamp
            if locker_demand[size] > max_locker_demand[size]:
                max_locker_demand[size] = locker_demand[size]
                max_demand_time[size] = current_time

            # Generate a pickup time and record it
            pickup_time = Simulator.generate_pickup_time(current_time)
            active_lockers[size].append(pickup_time)
            print(f'{size} Locker Assigned, Pickup Time: {pickup_time}')

    # Check and release lockers that have reached their pickup times
    for size in ['S', 'M', 'L']:
        active_lockers[size] = [pt for pt in active_lockers[size] if pt > current_time]
        lockers_released = locker_demand[size] - len(active_lockers[size])
        locker_demand[size] -= lockers_released

    # Print current locker demand
    print(f'Locker Demand at {current_time}: S={locker_demand["S"]}, M={locker_demand["M"]}, L={locker_demand["L"]}')
    print(f'Max Locker Demand so far: S={max_locker_demand["S"]} (at {max_demand_time["S"]}), '
          f'M={max_locker_demand["M"]} (at {max_demand_time["M"]}), '
          f'L={max_locker_demand["L"]} (at {max_demand_time["L"]})')

    # Advance to the next hour
    current_time += timedelta(hours=1)

# Print final results
print("Final Maximum Locker Demand and Times:")
print(f"S: {max_locker_demand['S']} at {max_demand_time['S']}, "
      f"M: {max_locker_demand['M']} at {max_demand_time['M']}, "
      f"L: {max_locker_demand['L']} at {max_demand_time['L']}")
