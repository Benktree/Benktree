import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from collections import Counter

# Load the Excel file and preprocess the data
file_path = 'D:/pythonproject/caculate/Casework 4/duration.xlsx'
duration_df = pd.read_excel(file_path, sheet_name='Sheet1', header=None, engine='openpyxl')

# Assuming the main data starts from row 2 (index 1), and column headers are at row 1 (index 0)
# Clean the DataFrame by setting proper column names
duration_df.columns = [f'Hour_{i}' for i in range(len(duration_df.columns))]

# Drop irrelevant rows/columns (if there are extra headers or empty rows at the beginning)
duration_df = duration_df.drop([0]).reset_index(drop=True)
duration_df = duration_df.drop(duration_df.columns[0], axis=1)

# Extract the probability matrix and normalize it if it's in a scaled format
probability_matrix = duration_df.iloc[:, :24].astype(float).values
probability_matrix = probability_matrix / 10000  # Assuming data is in X10,000 format to convert to probabilities


def generate_pickup_time(deposit_time):
    """
    Generate the pickup datetime based on the deposit datetime.

    Args:
    deposit_time (datetime): The datetime when the deposit was made.

    Returns:
    datetime: The datetime for the pickup time.
    """
    # Parse the deposit hour
    deposit_hour = deposit_time.hour

    # Simulate the pickup hour
    probabilities = probability_matrix[deposit_hour]
    probabilities /= probabilities.sum()  # Ensure the probabilities sum to 1
    pickup_hour = np.random.choice(range(24), p=probabilities)  # Choose a pickup hour based on probabilities
    print(pickup_hour)

    if pickup_hour == 23:
        pickup_hour = 0
    else:
        pickup_hour += 1

    # Convert the pickup hour to a datetime object based on the deposit time
    if pickup_hour < deposit_hour:
        pickup_datetime = deposit_time + timedelta(days=1)
    else:
        pickup_datetime = deposit_time

    # Set the correct hour for pickup
    pickup_datetime = pickup_datetime.replace(hour=pickup_hour, minute=0, second=0, microsecond=0)
    return pickup_datetime


pickup_hour_counter = Counter()

# Loop 800 times to generate pickup times and record the results
for _ in range(2000):
    deposit_time = datetime(2024, 1, 1, 23, 0)

    # Call the generate_pickup_time function from the Simulator class
    pickup_datetime = generate_pickup_time(deposit_time)

    # Extract the hour from the generated pickup time
    pickup_hour = pickup_datetime.hour

    # Record the occurrence of this pickup hour
    pickup_hour_counter[pickup_hour] += 1

# Display the counts of each pickup hour (0-23)
print("Pickup hour occurrences over 800 iterations:")
for hour, count in sorted(pickup_hour_counter.items()):
    print(f"Hour {hour}: {count} times")

