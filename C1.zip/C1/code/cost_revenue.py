# input paramter: [left lower point location(x,y), width(constant), height, locker size, locker number


