# allocation_methods.py

def strawman_allocation(size, locker_demand, locker_capacity):
    """
    Implements the Strawman Heuristic for locker allocation.

    Parameters:
    - size (str): Size of the package ('S', 'M', or 'L').
    - locker_demand (dict): Current number of lockers occupied for each size.
    - locker_capacity (dict): Total number of lockers available for each size.

    Returns:
    - allocation (str or None): The locker size allocated ('S', 'M', 'L'), or None if rejected.
    """
    allocation = None

    if size == 'S':
        # Try to allocate an 'S' locker
        if locker_demand['S'] < locker_capacity['S']:
            allocation = 'S'
        elif locker_demand['M'] < locker_capacity['M']:
            allocation = 'M'
        elif locker_demand['L'] < locker_capacity['L']:
            allocation = 'L'
    elif size == 'M':
        # Try to allocate an 'M' locker
        if locker_demand['M'] < locker_capacity['M']:
            allocation = 'M'
        elif locker_demand['L'] < locker_capacity['L']:
            allocation = 'L'
    elif size == 'L':
        # Try to allocate an 'L' locker
        if locker_demand['L'] < locker_capacity['L']:
            allocation = 'L'

    return allocation


def new_allocation_method(size, locker_demand, locker_capacity, predicted_demand, predicted_pickup_time):
    """
    Implements the new allocation method based on package size, locker availability,
    predicted demand, and predicted pickup time.

    Parameters:
    - size (str): Size of the package ('S', 'M', or 'L').
    - locker_demand (dict): Current number of lockers occupied for each size.
    - locker_capacity (dict): Total number of lockers available for each size.
    - predicted_demand (dict): Predicted package demand for the next hour for each size.
    - predicted_pickup_time (float): Predicted pickup time in hours for the package.

    Returns:
    - allocation (str or None): The locker size allocated ('S', 'M', 'L'), or None if rejected.
    """
    allocation = None  # Initialize allocation as None (rejected by default)

    if size == 'L':
        # Large Packages
        if locker_demand['L'] < locker_capacity['L']:
            # Directly allocate a large locker
            allocation = 'L'
        else:
            # No large locker is available, reject the large package request
            allocation = None

    elif size == 'M':
        # Medium Packages
        if locker_demand['M'] < locker_capacity['M']:
            # Directly allocate a medium locker
            allocation = 'M'
        elif locker_demand['L'] < locker_capacity['L']:
            # No medium locker available but large lockers are vacant
            remaining_large_lockers = locker_capacity['L'] - locker_demand['L']
            if predicted_demand['L'] == 0:
                # No large package demand expected in the next hour
                if predicted_pickup_time <= 1:
                    # Package pickup is predicted within one hour of placement
                    allocation = 'L'
                else:
                    # Storage time exceeds one hour, reject the request
                    allocation = None
            else:
                # Large package demand is expected in the next hour
                if predicted_demand['L'] <= remaining_large_lockers:
                    # Allow medium package storage in vacant large lockers
                    allocation = 'L'
                else:
                    # Reject medium package request to reserve large lockers
                    allocation = None
        else:
            # No medium or large lockers available, reject the request
            allocation = None

    elif size == 'S':
        # Small Packages
        if locker_demand['S'] < locker_capacity['S']:
            # Directly allocate a small locker
            allocation = 'S'
        elif locker_demand['M'] < locker_capacity['M']:
            # Small lockers are full but medium lockers are available
            remaining_medium_lockers = locker_capacity['M'] - locker_demand['M']
            if predicted_demand['M'] == 0:
                # No medium package demand expected in the next hour
                if predicted_pickup_time <= 1:
                    # Package pickup is predicted within one hour of placement
                    allocation = 'M'
                else:
                    # Storage time exceeds one hour, reject the request
                    allocation = None
            else:
                # Medium package demand is expected in the next hour
                if predicted_demand['M'] <= remaining_medium_lockers:
                    # Allow small package storage in vacant medium lockers
                    allocation = 'M'
                else:
                    # Reject small package request to reserve medium lockers
                    allocation = None
        elif locker_demand['L'] < locker_capacity['L']:
            # Both small and medium lockers are full but large lockers are available
            remaining_large_lockers = locker_capacity['L'] - locker_demand['L']
            if predicted_demand['L'] == 0:
                # No large package demand expected in the next hour
                if predicted_pickup_time <= 1:
                    # Package pickup is predicted within one hour of placement
                    allocation = 'L'
                else:
                    # Storage time exceeds one hour, reject the request
                    allocation = None
            else:
                # Large package demand is expected in the next hour
                if predicted_demand['L'] <= remaining_large_lockers:
                    # Allow small package storage in vacant large lockers
                    allocation = 'L'
                else:
                    # Reject small package request to reserve large lockers
                    allocation = None
        else:
            # No lockers available, reject the request
            allocation = None
    else:
        # Unknown package size, reject the request
        allocation = None

    return allocation
