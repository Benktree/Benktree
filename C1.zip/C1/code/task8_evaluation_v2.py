from simulator import Simulator
from datetime import datetime, timedelta
import numpy as np

# Configuration Section: Easily modify input values here

# Experiment parameter setting
# __________________________________________________________________________

# Define initial locker capacities
initial_locker_capacity = {'XS': 16, 'S': 26, 'M': 34, 'L': 30}

# Current locker capacities (modifiable)
locker_capacity = initial_locker_capacity.copy()

# Module numbers corresponding to each module type (0-5)
module_number = {'0': 5, '1': 1, '2': 7}

# Module costs corresponding to each module type (0-5)
module_cost = [321, 744, 313]  # Indices 0 to 5 correspond to modules '0' to '5'

location_parameter = 1

# __________________________________________________________________________

# Number of simulation runs
n_runs = 2

# Years to simulate
years_to_simulate = range(2024, 2029)  # 2024 to 2028 inclusive

# Revenue per accepted package per size
revenue_per_size = {'XS': 6.1, 'S': 6.1, 'M': 11.95, 'L': 16.35}

# Ergonomics cost per accepted package per size
ergonomics_cost_per_size = {'XS': 0.5, 'S': 0.5, 'M': 0.25, 'L': 0.25}

def locker_size(X):
    if 0 <= X <= 3:
        return 'XS'
    elif 4 <= X <= 6:
        return 'S'
    elif 7 <= X <= 12:
        return 'M'
    elif 13 <= X <= 18:
        return 'L'
    else:
        return None

# Define four-week demand share
four_week_demand_share = [0.06, 0.05, 0.06, 0.07, 0.09, 0.06, 0.04, 0.1, 0.1, 0.06, 0.08, 0.1, 0.13]

# Define Δdemand to locker capacity changes mapping
# Positive Δdemand indicates increase, Negative Δdemand indicates decrease
delta_to_capacity_change = {
    2999: {'XS': 0, 'S': 0, 'M': 0, 'L': 0},
    3000: {'XS': 2, 'S': 2, 'M': 3, 'L': 2},
    6000: {'XS': 2, 'S': 2, 'M': 3, 'L': 1},
    9000: {'XS': 2, 'S': 2, 'M': 3, 'L': 2},
    12000: {'XS': 2, 'S': 2, 'M': 3, 'L': 2},
    15000: {'XS': 2, 'S': 2, 'M': 3, 'L': 2},
    18000: {'XS': 2, 'S': 2, 'M': 3, 'L': 2},
}

# Define Δdemand to module number changes mapping based on the provided table
delta_to_module_change = {
    2999: {'0': 0, '1': 0, '2': 0},
    3000: {'0': 0, '1': 0, '2': 1},
    6000: {'0':0, '1': 1, '2': 0},
    9000: {'0': 0, '1': 0, '2': 1},
    12000: {'0': 0, '1': 0, '2': 1},
    15000: {'0': 0, '1': 0, '2': 1},
    18000: {'0': 0, '1': 0, '2': 1},
}

# Sorted list of Δdemand values for mapping
sorted_deltas = sorted(delta_to_capacity_change.keys())

def get_capacity_changes(delta_demand):
    for delta in sorted_deltas:
        if delta_demand <= delta:
            return delta_to_capacity_change[delta]
    return delta_to_capacity_change[sorted_deltas[-1]]  # Return the highest delta's changes

def get_module_changes(delta_demand):
    for delta in sorted_deltas:
        if delta_demand <= delta:
            return delta_to_module_change[delta]
    return delta_to_module_change[sorted_deltas[-1]]  # Return the highest delta's changes

# Dictionaries to collect metrics over runs
average_utilization_over_runs = {year: {'XS': 0, 'S': 0, 'M': 0, 'L': 0} for year in years_to_simulate}
service_level_over_runs = {year: 0 for year in years_to_simulate}
rejects_per_size_over_runs = {year: {'XS': 0, 'S': 0, 'M': 0, 'L': 0} for year in years_to_simulate}
accepts_per_size_over_runs = {year: {'XS': 0, 'S': 0, 'M': 0, 'L': 0} for year in years_to_simulate}
revenue_over_runs = {year: 0 for year in years_to_simulate}
ergonomics_cost_over_runs = {year: 0 for year in years_to_simulate}

# Initialize variables for 5-year totals
total_revenue_5_years = 0
total_ergonomics_cost_5_years = 0
total_service_level = 0
total_utilization = {'XS': 0, 'S': 0, 'M': 0, 'L': 0}
total_hours = 0  # Total hours over 5 years

# Initialize maximum module numbers
max_module_number = {'0': module_number['0'], '1': module_number['1'], '2': module_number['2'],
                    }

# Loop over n_runs
for run in range(n_runs):
    print(f"\nStarting simulation run {run+1}/{n_runs}")

    # Set time range
    start_time = datetime(2024, 1, 1, 0, 0)
    end_time = datetime(2029, 1, 1, 0, 0)

    # Initialize current time
    current_time = start_time

    # Initialize locker demand dictionary
    locker_demand = {'XS': 0, 'S': 0, 'M': 0, 'L': 0}

    # Record pickup times for lockers to release
    active_lockers = {'XS': [], 'S': [], 'M': [], 'L': []}

    # Initialize total demands and rejects
    total_demands = 0
    total_rejects = 0

    # Initialize yearly utilization and rejects per size
    yearly_utilization_hours = {year: {'XS': 0, 'S': 0, 'M': 0, 'L': 0} for year in years_to_simulate}
    yearly_hours = {year: 0 for year in years_to_simulate}
    yearly_total_demands = {year: {'XS': 0, 'S': 0, 'M': 0, 'L': 0} for year in years_to_simulate}
    yearly_total_rejects = {year: {'XS': 0, 'S': 0, 'M': 0, 'L': 0} for year in years_to_simulate}
    yearly_accepts_per_size = {year: {'XS': 0, 'S': 0, 'M': 0, 'L': 0} for year in years_to_simulate}
    yearly_revenue = {year: 0 for year in years_to_simulate}
    yearly_ergonomics_cost = {year: 0 for year in years_to_simulate}

    # Generate yearly demand
    yearly_demand_list = Simulator.generate_five_year_demand()
    yearly_demand_input = yearly_demand_list
    print(f"Yearly demand list: {yearly_demand_list}")

    # Convert yearly_demand_list to a dictionary mapping year to demand
    # 假设 yearly_demand_list 的顺序与 years_to_simulate 一致
    yearly_demand = {year: demand for year, demand in zip(years_to_simulate, yearly_demand_list)}
    print(f"Yearly demand dict: {yearly_demand}")

    # Initialize variables for 4-week period demand tracking
    previous_four_week_demand = None
    current_four_week_demand = None  # Initialize as None to handle the first period correctly
    current_four_week_period_key = None

    while current_time < end_time:
        year = current_time.year
        week_of_year = current_time.isocalendar()[1]
        four_week_period = (week_of_year - 1) // 4
        if four_week_period > 12:
            four_week_period = 12
        four_week_period_key = (year, four_week_period)

        # Check if four_week_period has changed
        if current_four_week_period_key != four_week_period_key:
            if current_four_week_period_key is not None and previous_four_week_demand is not None:
                # Calculate Δdemand based on the previous period
                delta_demand = current_four_week_demand - previous_four_week_demand
                print(f"\nAdjusting locker and module capacities for period {current_four_week_period_key}: Δdemand = {delta_demand}")

                if delta_demand != 0:
                    # Get capacity changes based on Δdemand
                    capacity_changes = get_capacity_changes(abs(delta_demand))
                    module_changes = get_module_changes(delta_demand)

                    if delta_demand > 0:
                        # Increasing capacities and modules
                        print(f"Increasing locker capacities based on Δdemand {delta_demand}: {capacity_changes}")
                        # Increase locker capacities
                        for size, change in capacity_changes.items():
                            locker_capacity[size] += change
                            print(f"Locker capacity for {size} increased to {locker_capacity[size]}")

                        print(f"Increasing module numbers based on Δdemand {delta_demand}: {module_changes}")
                        # Increase module numbers
                        for module_type, change in module_changes.items():
                            module_number[module_type] += change
                            # Update max_module_number
                            if module_number[module_type] > max_module_number[module_type]:
                                max_module_number[module_type] = module_number[module_type]
                            print(f"Module number for {module_type} increased to {module_number[module_type]}")
                    else:
                        # Decreasing capacities and modules
                        print(f"Decreasing locker capacities based on Δdemand {delta_demand}: {capacity_changes}")
                        # Decrease locker capacities
                        for size, change in capacity_changes.items():
                            locker_capacity[size] = max(locker_capacity[size] - change, initial_locker_capacity[size])
                            print(f"Locker capacity for {size} decreased to {locker_capacity[size]}")

                        print(f"Decreasing module numbers based on Δdemand {delta_demand}: {module_changes}")
                        # Decrease module numbers
                        for module_type, change in module_changes.items():
                            module_number[module_type] = max(module_number[module_type] - change, 0)  # Assuming module_number cannot be negative
                            print(f"Module number for {module_type} decreased to {module_number[module_type]}")
                else:
                    print("Δdemand is zero. No capacity adjustments made.")

            # Update period tracking
            if four_week_period < len(four_week_demand_share):
                share = four_week_demand_share[four_week_period]
            else:
                share = four_week_demand_share[-1]  # Use the last share if index out of range

            # Calculate new_four_week_demand based on yearly_demand and share
            new_four_week_demand = yearly_demand.get(year, 0) * share
            print(f"Setting new_four_week_demand for period {four_week_period_key}: {new_four_week_demand}")

            # Calculate delta_demand for the next period (if applicable)
            if previous_four_week_demand is not None:
                delta_demand_next = new_four_week_demand - previous_four_week_demand
            else:
                delta_demand_next = 0  # No adjustment for the first period

            # Update previous_four_week_demand
            previous_four_week_demand = current_four_week_demand
            current_four_week_demand = new_four_week_demand

            # Set the current period key
            current_four_week_period_key = four_week_period_key

        # Generate hourly demand
        # 修正这里，传递 yearly_demand 而不是 yearly_demand_input
        demand_hourly = location_parameter * Simulator.generate_hourly_demand(current_time, yearly_demand_input)


        # Process each demand
        for _ in range(demand_hourly):
            X = Simulator.generate_package_space()
            size = locker_size(X)

            if size is None:
                continue  # Ignore invalid package sizes

            total_demands += 1
            yearly_total_demands[year][size] += 1

            allocation = None

            # Implement Strawman Heuristic with 'XS' locker
            if size == 'XS':
                # Try to allocate an 'XS' locker
                if locker_demand['XS'] < locker_capacity['XS']:
                    allocation = 'XS'
                elif locker_demand['S'] < locker_capacity['S']:
                    allocation = 'S'
                elif locker_demand['M'] < locker_capacity['M']:
                    allocation = 'M'
                elif locker_demand['L'] < locker_capacity['L']:
                    allocation = 'L'
            elif size == 'S':
                # Try to allocate an 'S' locker
                if locker_demand['S'] < locker_capacity['S']:
                    allocation = 'S'
                elif locker_demand['M'] < locker_capacity['M']:
                    allocation = 'M'
                elif locker_demand['L'] < locker_capacity['L']:
                    allocation = 'L'
            elif size == 'M':
                # Try to allocate an 'M' locker
                if locker_demand['M'] < locker_capacity['M']:
                    allocation = 'M'
                elif locker_demand['L'] < locker_capacity['L']:
                    allocation = 'L'
            elif size == 'L':
                # Try to allocate an 'L' locker
                if locker_demand['L'] < locker_capacity['L']:
                    allocation = 'L'

            if allocation:
                # Assign locker
                locker_demand[allocation] += 1

                # Generate corresponding pickup time and record
                pickup_time = Simulator.generate_pickup_time(current_time)
                active_lockers[allocation].append(pickup_time)

                # Accumulate revenue
                yearly_revenue[year] += revenue_per_size[size]

                # Accumulate ergonomics cost
                yearly_ergonomics_cost[year] += ergonomics_cost_per_size[size]

                # Accumulate accepts per size
                yearly_accepts_per_size[year][size] += 1
            else:
                # Reject the request
                total_rejects += 1
                yearly_total_rejects[year][size] += 1

        # Release lockers whose pickup time has arrived
        for l_size in ['XS', 'S', 'M', 'L']:
            active_lockers[l_size] = [pt for pt in active_lockers[l_size] if pt > current_time]
            lockers_released = locker_demand[l_size] - len(active_lockers[l_size])
            locker_demand[l_size] -= lockers_released  # Update current demand

        # Accumulate yearly utilization hours
        for l_size in ['XS', 'S', 'M', 'L']:
            yearly_utilization_hours[year][l_size] += locker_demand[l_size]

        # Remove the accumulation of current_four_week_demand
        # current_four_week_demand += demand_hourly  # REMOVE THIS LINE

        # Accumulate yearly hours
        yearly_hours[year] += 1

        # Accumulate total hours
        total_hours += 1

        # Move to the next hour
        current_time += timedelta(hours=1)

    # After the loop ends, handle the last four-week period
    if previous_four_week_demand is not None and current_four_week_demand is not None:
        delta_demand = current_four_week_demand - previous_four_week_demand
        print(f"\nAdjusting locker and module capacities for the last period {current_four_week_period_key}: Δdemand = {delta_demand}")

        if delta_demand != 0:
            # Get capacity changes based on Δdemand
            capacity_changes = get_capacity_changes(abs(delta_demand))
            module_changes = get_module_changes(delta_demand)

            if delta_demand > 0:
                # Increasing capacities and modules
                print(f"Increasing locker capacities based on Δdemand {delta_demand}: {capacity_changes}")
                # Increase locker capacities
                for size, change in capacity_changes.items():
                    locker_capacity[size] += change
                    print(f"Locker capacity for {size} increased to {locker_capacity[size]}")

                print(f"Increasing module numbers based on Δdemand {delta_demand}: {module_changes}")
                # Increase module numbers
                for module_type, change in module_changes.items():
                    module_number[module_type] += change
                    # Update max_module_number
                    if module_number[module_type] > max_module_number[module_type]:
                        max_module_number[module_type] = module_number[module_type]
                    print(f"Module number for {module_type} increased to {module_number[module_type]}")
            else:
                # Decreasing capacities and modules
                print(f"Decreasing locker capacities based on Δdemand {delta_demand}: {capacity_changes}")
                # Decrease locker capacities
                for size, change in capacity_changes.items():
                    locker_capacity[size] = max(locker_capacity[size] - change, initial_locker_capacity[size])
                    print(f"Locker capacity for {size} decreased to {locker_capacity[size]}")

                print(f"Decreasing module numbers based on Δdemand {delta_demand}: {module_changes}")
                # Decrease module numbers
                for module_type, change in module_changes.items():
                    module_number[module_type] = max(module_number[module_type] - change, 0)  # Assuming module_number cannot be negative
                    print(f"Module number for {module_type} decreased to {module_number[module_type]}")
        else:
            print("Δdemand is zero. No capacity adjustments made.")

    # After each run, collect yearly metrics
    for year in years_to_simulate:
        # Calculate average utilization for each locker size
        for l_size in ['XS', 'S', 'M', 'L']:
            denominator = locker_capacity[l_size] * yearly_hours[year]
            if denominator > 0:
                utilization = yearly_utilization_hours[year][l_size] / denominator
            else:
                utilization = 0
            average_utilization_over_runs[year][l_size] += utilization

            # Accumulate total utilization over 5 years
            total_utilization[l_size] += yearly_utilization_hours[year][l_size]

        # Calculate service level
        demands = sum(yearly_total_demands[year].values())
        rejects = sum(yearly_total_rejects[year].values())
        service_level = (demands - rejects) / demands if demands > 0 else 0
        service_level_over_runs[year] += service_level

        # Accumulate total service level over 5 years
        total_service_level += service_level

        # Accumulate rejects per size
        for size in ['XS', 'S', 'M', 'L']:
            rejects_size = yearly_total_rejects[year][size]
            rejects_per_size_over_runs[year][size] += rejects_size

        # Accumulate accepts per size
        for size in ['XS', 'S', 'M', 'L']:
            accepts_size = yearly_accepts_per_size[year][size]
            accepts_per_size_over_runs[year][size] += accepts_size

        # Accumulate revenue
        revenue_over_runs[year] += yearly_revenue[year]

        # Accumulate ergonomics cost
        ergonomics_cost_over_runs[year] += yearly_ergonomics_cost[year]

        # Accumulate total revenue and ergonomics cost over 5 years
        total_revenue_5_years += yearly_revenue[year]
        total_ergonomics_cost_5_years += yearly_ergonomics_cost[year]

# After all runs, compute average metrics over runs
average_utilization_per_year = []
for year in years_to_simulate:
    # Average utilization
    avg_utilization_year = {}
    for l_size in ['XS', 'S', 'M', 'L']:
        average_utilization_over_runs[year][l_size] /= n_runs
        avg_utilization_year[l_size] = round(average_utilization_over_runs[year][l_size] * 100, 2)  # Convert to percentage and round

    average_utilization_per_year.append(avg_utilization_year)

    # Average service level
    service_level_over_runs[year] /= n_runs

    # Average rejects per size
    for size in ['XS', 'S', 'M', 'L']:
        rejects_per_size_over_runs[year][size] /= n_runs

    # Average accepts per size
    for size in ['XS', 'S', 'M', 'L']:
        accepts_per_size_over_runs[year][size] /= n_runs

    # Average revenue and ergonomics cost
    revenue_over_runs[year] /= n_runs
    ergonomics_cost_over_runs[year] /= n_runs

# Calculate five-year average utilization per locker size
five_year_avg_utilization = {'XS': 0, 'S': 0, 'M': 0, 'L': 0}
for l_size in ['XS', 'S', 'M', 'L']:
    total_util = 0
    for year in years_to_simulate:
        total_util += average_utilization_over_runs[year][l_size]
    five_year_avg_utilization[l_size] = round((total_util / len(years_to_simulate)) * 100, 2)  # Convert to percentage and round

# Calculate average service level over 5 years
average_service_level_5_years = (total_service_level / len(years_to_simulate)) * 100  # Convert to percentage

# Compute implement_cost based on max_module_number and module_cost list
implement_cost = 0
for module_type, max_num in max_module_number.items():
    implement_cost += max_num * module_cost[int(module_type)]

# Print average metrics over runs per year
for year_index, year in enumerate(years_to_simulate):
    print(f"\nYear: {year}")
    for l_size in ['XS', 'S', 'M', 'L']:
        avg_util = 100 * average_utilization_over_runs[year][l_size]  # Already in percentage
        print(f"  {l_size} Average Utilization: {avg_util:.2f}%")
    service_level = service_level_over_runs[year] * 100  # Convert to percentage
    print(f"  Service Level: {service_level:.2f}%")
    rejects_per_size = {size: int(rejects_per_size_over_runs[year][size]) for size in ['XS', 'S', 'M', 'L']}
    print(f"  Rejects per Size: {rejects_per_size}")
    accepts_per_size = {size: int(accepts_per_size_over_runs[year][size]) for size in ['XS', 'S', 'M', 'L']}
    print(f"  Accepted Packages per Size: {accepts_per_size}")
    total_revenue = revenue_over_runs[year]
    total_ergonomics_cost = ergonomics_cost_over_runs[year]
    print(f"  Total Revenue: ${total_revenue:.2f}")
    print(f"  Total Ergonomics Cost: ${total_ergonomics_cost:.2f}")

print("\nAverage Results over {} Runs:".format(n_runs))

# Print 5-Year aggregated results
print("\n5-Year Aggregated Results:")
print(f"  Total Revenue over 5 Years: ${total_revenue_5_years:.2f}")
print(f"  Total Ergonomics Cost over 5 Years: ${total_ergonomics_cost_5_years:.2f}")
print(f"Acquisition and implementation cost (A & I): $ {implement_cost:.2f}")
print(f"Total Profit over 5 years: ${total_revenue_5_years - total_ergonomics_cost_5_years - implement_cost:.2f}")
print(f"  Average Service Level over 5 Years: {average_service_level_5_years/n_runs:.2f}%")
print("  Five-Year Average Utilization per Locker Size:")
for l_size in ['XS', 'S', 'M', 'L']:
    avg_util_5_years = five_year_avg_utilization[l_size]
    print(f"    {l_size}: {avg_util_5_years:.2f}%")

# Print average utilization per year in the specified format
print("\nAverage Utilization per Year:")
utilization_per_year = []
for idx, avg_utilization_year in enumerate(average_utilization_per_year):
    year_utilization = {size: avg_utilization_year[size]/100 for size in ['XS', 'S', 'M', 'L']}
    utilization_per_year.append(year_utilization)
    print(year_utilization)
    print(",")
