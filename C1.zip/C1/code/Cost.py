# cost_calculator.py

def calculate_ergonomics_cost(locker_info, size_combo):
    """
    Calculate the cost based on specified size combinations and locker information.

    Parameters:
    - locker_info (tuple): Contains locker information, e.g., (0, y_l, 2, 6, 2, 'A').
    - size_combo (tuple): Size combination, e.g., ('S', 'S'), ('S', 'M'), ('M', 'L').

    Returns:
    - float: The calculated ergonomics cost.
    """
    y_l = locker_info[1]  # Extract y_l from the input data

    # Map size combinations to specific cost types
    size_to_cost_type = {
        ('XS', 'XS'): 'cA11',
        ('XS', 'S'): 'cA11',
        ('XS', 'M'): 'cA12',
        ('XS', 'L'): 'cA13',
        ('S', 'S'): 'cA11',
        ('S', 'M'): 'cA12',
        ('S', 'L'): 'cA13',
        ('M', 'M'): 'cA22',
        ('M', 'L'): 'cA23',
        ('L', 'L'): 'cA33',
    }

    # Get the corresponding cost type
    cost_type = size_to_cost_type.get(size_combo)
    if not cost_type:
        raise ValueError("Unknown size combination: {}".format(size_combo))

    # Calculate cost based on the cost type
    if cost_type == 'cA11':
        if y_l <= 7:
            return 0.01 * (115 - 15 * y_l)
        else:
            return 0.01 * (-95 + 15 * y_l)

    elif cost_type == 'cA12':
        if y_l <= 7:
            return 0.01 * ((75 + (65 / 6)) - (65 / 6) * y_l)
        else:
            return 0.01 * (10 - (7 * (65 / 6)) + (65 / 6) * y_l)

    elif cost_type == 'cA13':
        if y_l <= 7:
            return 0.01 * ((50 + (40 / 6)) - (40 / 6) * y_l)
        else:
            return 0.01 * (10 - (7 * (40 / 6)) + (40 / 6) * y_l)

    elif cost_type == 'cA22':
        return 0.01 * ((10 - (65 / 14)) + (65 / 14) * y_l)

    elif cost_type == 'cA23' or cost_type == 'cA33':
        return 0.01 * ((10 - (90 / 14)) + (90 / 14) * y_l)

    else:
        raise ValueError("Unknown cost type: {}".format(cost_type))


def calculate_implement_cost(H, module_number, module_cost):
    """
    Calculate the total implementation cost based on the given parameters.

    Parameters:
    - H (float): The height of the modules.
    - module_number (list): List of module quantities.
    - module_cost (list): List of module costs corresponding to the module numbers.

    Returns:
    - float: The total implementation cost.
    """
    # Constants
    w = 1.3
    cs = 50
    cw = 500

    # Calculate implement_cost
    implement_cost = sum(n * c for n, c in zip(module_number, module_cost))

    # Calculate W (Total width)
    W = sum(module_number) * w

    # Calculate total cost
    cost = implement_cost + cw * W + 2 * cs * (W + H)

    return cost
