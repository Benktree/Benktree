from simulator import Simulator
from datetime import datetime, timedelta
import numpy as np
from scipy.stats import t  # Import t-distribution for confidence intervals
from Cost import calculate_implement_cost

# Configuration Section: Easily modify input values here

# Experiment parameter setting
# __________________________________________________________________________

# Define locker capacities
locker_capacity = {'XS': 12, 'S': 73, 'M': 37, 'L': 52}

# Module numbers corresponding to each locker size
module_number = [10, 2, 6, 3]  # XS, S, M, L respectively

# Module costs corresponding to each locker size
module_cost = [827, 753, 810, 809]  # XS, S, M, L respectively

location_parameter = 1

# __________________________________________________________________________

# Number of simulation runs
n_runs = 50  # Increased number of runs for statistical significance

# Years to simulate
years_to_simulate = range(2024, 2029)

# Revenue per accepted package per size
revenue_per_size = {'XS': 6.1, 'S': 6.1, 'M': 11.95, 'L': 16.35}

# Ergonomics cost per accepted package per size
ergonomics_cost_per_size = {'XS': 0.5, 'S': 0.5, 'M': 0.25, 'L': 0.25}

def locker_size(X):
    if 0 <= X <= 3:
        return 'XS'
    elif 4 <= X <= 6:
        return 'S'
    elif 7 <= X <= 12:
        return 'M'
    elif 13 <= X <= 18:
        return 'L'
    else:
        return None

# Dictionaries and lists to collect metrics over runs
average_utilization_over_runs = {year: {'XS': [], 'S': [], 'M': [], 'L': []} for year in years_to_simulate}
service_level_over_runs = {year: [] for year in years_to_simulate}
rejects_per_size_over_runs = {year: {'XS': [], 'S': [], 'M': [], 'L': []} for year in years_to_simulate}
accepts_per_size_over_runs = {year: {'XS': [], 'S': [], 'M': [], 'L': []} for year in years_to_simulate}
revenue_over_runs = {year: [] for year in years_to_simulate}
ergonomics_cost_over_runs = {year: [] for year in years_to_simulate}

profits_over_runs = []
average_utilization_5_years_over_runs = {'XS': [], 'S': [], 'M': [], 'L': []}
average_service_levels_over_runs = []

# Loop over n_runs
for run in range(n_runs):
    print(f"\nStarting simulation run {run+1}/{n_runs}")

    # Initialize variables for 5-year totals for this run
    total_revenue_5_years = 0
    total_ergonomics_cost_5_years = 0
    total_service_level = 0
    total_utilization = {'XS': 0, 'S': 0, 'M': 0, 'L': 0}
    total_hours = 0  # Total hours over 5 years

    # Set time range
    start_time = datetime(2024, 1, 1, 0, 0)
    end_time = datetime(2029, 1, 1, 0, 0)

    # Initialize current time
    current_time = start_time

    # Initialize locker demand dictionary
    locker_demand = {'XS': 0, 'S': 0, 'M': 0, 'L': 0}

    # Record pickup times for lockers to release
    active_lockers = {'XS': [], 'S': [], 'M': [], 'L': []}

    # Calculate acquisition and implementation cost
    implement_cost = calculate_implement_cost(6.9, module_number, module_cost)

    # Initialize total demands and rejects
    total_demands = 0
    total_rejects = 0

    # Initialize yearly utilization and rejects per size
    yearly_utilization_hours = {year: {'XS': 0, 'S': 0, 'M': 0, 'L': 0} for year in years_to_simulate}
    yearly_hours = {year: 0 for year in years_to_simulate}
    yearly_total_demands = {year: {'XS': 0, 'S': 0, 'M': 0, 'L': 0} for year in years_to_simulate}
    yearly_total_rejects = {year: {'XS': 0, 'S': 0, 'M': 0, 'L': 0} for year in years_to_simulate}
    yearly_accepts_per_size = {year: {'XS': 0, 'S': 0, 'M': 0, 'L': 0} for year in years_to_simulate}
    yearly_revenue = {year: 0 for year in years_to_simulate}
    yearly_ergonomics_cost = {year: 0 for year in years_to_simulate}

    # Generate yearly demand
    yearly_demand = Simulator.generate_five_year_demand()

    while current_time < end_time:
        year = current_time.year



        # Accumulate yearly hours and total hours
        yearly_hours[year] += 1
        total_hours += 1



        # Generate hourly demand
        demand_hourly = location_parameter * Simulator.generate_hourly_demand(current_time, yearly_demand)

        # Process each demand
        for _ in range(demand_hourly):
            X = Simulator.generate_package_space()
            size = locker_size(X)

            total_demands += 1
            yearly_total_demands[year][size] += 1

            allocation = None

            # Implement Strawman Heuristic with 'XS' locker
            if size == 'XS':
                # Try to allocate an 'XS' locker
                if locker_demand['XS'] < locker_capacity['XS']:
                    allocation = 'XS'
                elif locker_demand['S'] < locker_capacity['S']:
                    allocation = 'S'
                elif locker_demand['M'] < locker_capacity['M']:
                    allocation = 'M'
                elif locker_demand['L'] < locker_capacity['L']:
                    allocation = 'L'
            elif size == 'S':
                # Try to allocate an 'S' locker
                if locker_demand['S'] < locker_capacity['S']:
                    allocation = 'S'
                elif locker_demand['M'] < locker_capacity['M']:
                    allocation = 'M'
                elif locker_demand['L'] < locker_capacity['L']:
                    allocation = 'L'
            elif size == 'M':
                # Try to allocate an 'M' locker
                if locker_demand['M'] < locker_capacity['M']:
                    allocation = 'M'
                elif locker_demand['L'] < locker_capacity['L']:
                    allocation = 'L'
            elif size == 'L':
                # Try to allocate an 'L' locker
                if locker_demand['L'] < locker_capacity['L']:
                    allocation = 'L'

            if allocation:
                # Assign locker
                locker_demand[allocation] += 1

                # Generate corresponding pickup time and record
                pickup_time = Simulator.generate_pickup_time(current_time)
                active_lockers[allocation].append(pickup_time)

                # Accumulate revenue
                yearly_revenue[year] += revenue_per_size[size]

                # Accumulate ergonomics cost
                yearly_ergonomics_cost[year] += ergonomics_cost_per_size[size]

                # Accumulate accepts per size
                yearly_accepts_per_size[year][size] += 1

            else:
                # Reject the request
                total_rejects += 1
                yearly_total_rejects[year][size] += 1

        # Release lockers whose pickup time has arrived
        for l_size in ['XS', 'S', 'M', 'L']:
            active_lockers[l_size] = [pt for pt in active_lockers[l_size] if pt > current_time]
            lockers_released = locker_demand[l_size] - len(active_lockers[l_size])
            locker_demand[l_size] -= lockers_released  # Update current demand

        # Accumulate yearly utilization hours
        for l_size in ['XS', 'S', 'M', 'L']:
            yearly_utilization_hours[year][l_size] += locker_demand[l_size]

        # Move to the next hour
        current_time += timedelta(hours=1)

    # After each run, collect yearly metrics
    for year in years_to_simulate:
        # Calculate average utilization for each locker size
        for l_size in ['XS', 'S', 'M', 'L']:
            utilization = yearly_utilization_hours[year][l_size] / (locker_capacity[l_size] * yearly_hours[year])
            average_utilization_over_runs[year][l_size].append(utilization)

            # Accumulate total utilization over 5 years
            total_utilization[l_size] += yearly_utilization_hours[year][l_size]

        # Calculate service level
        demands = sum(yearly_total_demands[year].values())
        rejects = sum(yearly_total_rejects[year].values())
        service_level = (demands - rejects) / demands if demands > 0 else 0
        service_level_over_runs[year].append(service_level)

        # Accumulate total service level over 5 years
        total_service_level += service_level

        # Accumulate rejects per size
        for size in ['XS', 'S', 'M', 'L']:
            rejects_size = yearly_total_rejects[year][size]
            rejects_per_size_over_runs[year][size].append(rejects_size)

        # Accumulate accepts per size
        for size in ['XS', 'S', 'M', 'L']:
            accepts_size = yearly_accepts_per_size[year][size]
            accepts_per_size_over_runs[year][size].append(accepts_size)

        # Accumulate revenue
        revenue_over_runs[year].append(yearly_revenue[year])

        # Accumulate ergonomics cost
        ergonomics_cost_over_runs[year].append(yearly_ergonomics_cost[year])

        # Accumulate total revenue and ergonomics cost over 5 years
        total_revenue_5_years += yearly_revenue[year]
        total_ergonomics_cost_5_years += yearly_ergonomics_cost[year]

    # Calculate overall average utilization over 5 years for this run
    average_utilization_5_years = {}
    for l_size in ['XS', 'S', 'M', 'L']:
        total_capacity_hours = locker_capacity[l_size] * total_hours
        average_utilization = total_utilization[l_size] / total_capacity_hours
        average_utilization_5_years_over_runs[l_size].append(average_utilization)

    # Calculate average service level over 5 years for this run
    average_service_level_5_years = total_service_level / len(years_to_simulate)
    average_service_levels_over_runs.append(average_service_level_5_years)

    # Calculate profit for this run and collect
    profit = total_revenue_5_years - total_ergonomics_cost_5_years - implement_cost
    profits_over_runs.append(profit)

# After all runs, compute average metrics over runs
average_utilization_per_year = []
for year in years_to_simulate:
    # Average utilization
    avg_utilization_year = {}
    for l_size in ['XS', 'S', 'M', 'L']:
        avg_utilization = np.mean(average_utilization_over_runs[year][l_size])
        avg_utilization_year[l_size] = avg_utilization

    average_utilization_per_year.append(avg_utilization_year)

    # Average service level
    service_level_over_runs[year] = np.mean(service_level_over_runs[year])

    # Average rejects per size
    for size in ['XS', 'S', 'M', 'L']:
        rejects_per_size_over_runs[year][size] = np.mean(rejects_per_size_over_runs[year][size])

    # Average accepts per size
    for size in ['XS', 'S', 'M', 'L']:
        accepts_per_size_over_runs[year][size] = np.mean(accepts_per_size_over_runs[year][size])

    # Average revenue and ergonomics cost
    revenue_over_runs[year] = np.mean(revenue_over_runs[year])
    ergonomics_cost_over_runs[year] = np.mean(ergonomics_cost_over_runs[year])

# Calculate overall average utilization over 5 years
average_utilization_5_years = {}
for l_size in ['XS', 'S', 'M', 'L']:
    average_utilization_5_years[l_size] = np.mean(average_utilization_5_years_over_runs[l_size])

# Calculate average service level over 5 years
average_service_level_5_years = np.mean(average_service_levels_over_runs)

# Print average metrics over runs per year
for year_index, year in enumerate(years_to_simulate):
    print(f"\nYear: {year}")
    for l_size in ['XS', 'S', 'M', 'L']:
        avg_util = average_utilization_per_year[year_index][l_size] * 100  # Convert to percentage
        print(f"  {l_size} Average Utilization: {avg_util:.2f}%")
    service_level = service_level_over_runs[year] * 100  # Convert to percentage
    print(f"  Service Level: {service_level:.2f}%")
    rejects_per_size = {size: int(rejects_per_size_over_runs[year][size]) for size in ['XS', 'S', 'M', 'L']}
    print(f"  Rejects per Size: {rejects_per_size}")
    accepts_per_size = {size: int(accepts_per_size_over_runs[year][size]) for size in ['XS', 'S', 'M', 'L']}
    print(f"  Accepted Packages per Size: {accepts_per_size}")
    total_revenue = revenue_over_runs[year]
    total_ergonomics_cost = ergonomics_cost_over_runs[year]
    print(f"  Total Revenue: ${total_revenue:.2f}")
    print(f"  Total Ergonomics Cost: ${total_ergonomics_cost:.2f}")

print("\nAverage Results over {} Runs:".format(n_runs))

# Print 5-Year aggregated results
total_revenue_5_years = sum([np.mean(revenue_over_runs[year]) for year in years_to_simulate])
total_ergonomics_cost_5_years = sum([np.mean(ergonomics_cost_over_runs[year]) for year in years_to_simulate])
profit_mean = np.mean(profits_over_runs)
profit_std = np.std(profits_over_runs, ddof=1)
t_value = t.ppf(0.975, df=n_runs - 1)
profit_se = profit_std / np.sqrt(n_runs)
profit_ci_lower = profit_mean - t_value * profit_se
profit_ci_upper = profit_mean + t_value * profit_se

print("\n5-Year Aggregated Results:")
print(f"  Total Revenue over 5 Years: ${total_revenue_5_years:.2f}")
print(f"  Total Ergonomics Cost over 5 Years: ${total_ergonomics_cost_5_years:.2f}")
print(f"  Acquisition and Implementation Cost (A & I): ${implement_cost:.2f}")
print(f"  Total Profit over 5 Years: ${profit_mean:.2f}")
print(f"    95% Confidence Interval: (${profit_ci_lower:.2f}, ${profit_ci_upper:.2f})")
print(f"  Average Service Level over 5 Years: {average_service_level_5_years * 100:.2f}%")
print("  Average Utilization over 5 Years per Locker Size:")
for l_size in ['XS', 'S', 'M', 'L']:
    avg_util_overall = average_utilization_5_years[l_size] * 100  # Convert to percentage
    utilization_array = np.array(average_utilization_5_years_over_runs[l_size])
    utilization_std = np.std(utilization_array, ddof=1)
    utilization_se = utilization_std / np.sqrt(n_runs)
    utilization_ci_lower = average_utilization_5_years[l_size] - t_value * utilization_se
    utilization_ci_upper = average_utilization_5_years[l_size] + t_value * utilization_se
    print(f"    {l_size}: {avg_util_overall:.2f}%")
    print(f"      95% Confidence Interval: ({utilization_ci_lower * 100:.2f}%, {utilization_ci_upper * 100:.2f}%)")

# Print average utilization per year in the specified format
print("\nAverage Utilization per Year:")
for idx, avg_utilization_year in enumerate(average_utilization_per_year):
    year_utilization = {size: round(avg_utilization_year[size], 4) for size in ['XS', 'S', 'M', 'L']}
    print(year_utilization)
    print(",")
    # print(f"Year {idx + 1}: {year_utilization}")

# Print overall 5-year average utilization
average_utilization_overall = {size: round(average_utilization_5_years[size], 4) for size in ['XS', 'S', 'M', 'L']}
print("\nOverall 5-Year Average Utilization:")
print([average_utilization_overall])
