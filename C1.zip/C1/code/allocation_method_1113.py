# main_simulation.py

from simulator import Simulator
from datetime import datetime, timedelta
import numpy as np
from allocation_method import new_allocation_method  # Import the allocation methods module

def locker_size(X):
    if 0 <= X <= 6:
        return 'S'
    elif 7 <= X <= 12:
        return 'M'
    elif 13 <= X <= 18:
        return 'L'
    else:
        return None

# Set time range
start_time = datetime(2024, 1, 1, 0, 0)
end_time = datetime(2029, 1, 1, 0, 0)

# Initialize current time
current_time = start_time

# Initialize locker demand dictionary
locker_demand = {'S': 0, 'M': 0, 'L': 0}

# Record max locker demand and corresponding time
max_locker_demand = {'S': 0, 'M': 0, 'L': 0}
max_demand_time = {'S': None, 'M': None, 'L': None}

# Record pickup times for lockers to release
active_lockers = {'S': [], 'M': [], 'L': []}

# Define locker capacities
locker_capacity = {'S': 60, 'M': 40, 'L': 60}

# Initialize total demands and rejects
total_demands = 0
total_rejects = 0

# Initialize total utilization hours per locker size
total_utilization_hours = {'S': 0, 'M': 0, 'L': 0}

# Initialize four-month period utilization, demands, and rejects
period_utilization = {'S': {}, 'M': {}, 'L': {}}
period_demands = {}
period_rejects = {}
period_hours = {}

# Initialize yearly utilization and rejects per size
yearly_utilization_hours = {'S': {}, 'M': {}, 'L': {}}
yearly_hours = {}
yearly_total_demands = {}
yearly_total_rejects = {}
yearly_rejects_per_size = {}  # New dictionary to record rejects per size per year

# Initialize total hours
total_hours = 0

# Generate yearly demand
yearly_demand = Simulator.generate_five_year_demand()
print(yearly_demand)

# Choose the allocation method ('strawman' or 'new')
allocation_method_choice = 'new'  # Change this to 'strawman' to use the Strawman Heuristic

while current_time < end_time:
    # Get four-month period key
    period = ((current_time.month - 1) // 4) + 1  # Periods 1, 2, 3
    period_key = (current_time.year, period)
    year = current_time.year

    # Accumulate period hours
    if period_key not in period_hours:
        period_hours[period_key] = 0
    period_hours[period_key] += 1

    # Accumulate yearly hours
    if year not in yearly_hours:
        yearly_hours[year] = 0
    yearly_hours[year] += 1

    # Accumulate total hours
    total_hours += 1

    # Generate hourly demand
    demand_hourly = Simulator.generate_hourly_demand(current_time, yearly_demand)
    print(f'\nCurrent time: {current_time}')
    print(f'Hourly Demand: {demand_hourly}')

    # Process each demand
    for _ in range(demand_hourly):
        X = Simulator.generate_package_space()
        size = locker_size(X)

        total_demands += 1

        # Initialize period demands and rejects
        if period_key not in period_demands:
            period_demands[period_key] = 0
        if period_key not in period_rejects:
            period_rejects[period_key] = 0

        # Initialize yearly demands and rejects
        if year not in yearly_total_demands:
            yearly_total_demands[year] = 0
        if year not in yearly_total_rejects:
            yearly_total_rejects[year] = 0

        # Initialize yearly rejects per size
        if year not in yearly_rejects_per_size:
            yearly_rejects_per_size[year] = {'S': 0, 'M': 0, 'L': 0}

        period_demands[period_key] += 1
        yearly_total_demands[year] += 1

        allocation = None

        # Allocation logic
        if allocation_method_choice == 'strawman':
            # Use Strawman Heuristic
            allocation = allocation_methods.strawman_allocation(size, locker_demand, locker_capacity)
        elif allocation_method_choice == 'new':
            # Use the new allocation method
            # Predict demand for the next hour (you need to implement this prediction based on your data)
            predicted_demand = Simulator.predict_next_hour_demand(current_time, yearly_demand)
            # Generate predicted pickup time (you may use the same function or modify as needed)
            predicted_pickup_time = Simulator.predict_pickup_time(current_time)
            allocation = allocation_methods.new_allocation_method(
                size, locker_demand, locker_capacity, predicted_demand, predicted_pickup_time
            )
        else:
            raise ValueError("Unknown allocation method choice.")

        if allocation:
            # Assign locker
            locker_demand[allocation] += 1

            # Update max demand and its time
            if locker_demand[allocation] > max_locker_demand[allocation]:
                max_locker_demand[allocation] = locker_demand[allocation]
                max_demand_time[allocation] = current_time

            # Generate actual pickup time and record
            pickup_time = Simulator.generate_pickup_time(current_time)
            active_lockers[allocation].append(pickup_time)
            print(f'{allocation} Locker assigned to package of size {size}, Pickup Time: {pickup_time}')
        else:
            # Reject the request
            total_rejects += 1
            period_rejects[period_key] += 1
            yearly_total_rejects[year] += 1

            # Record reject per size
            yearly_rejects_per_size[year][size] += 1

            print(f'Package of size {size} rejected at {current_time}')

    # Release lockers whose pickup time has arrived
    for size in ['S', 'M', 'L']:
        active_lockers[size] = [pt for pt in active_lockers[size] if pt > current_time]
        lockers_released = locker_demand[size] - len(active_lockers[size])
        locker_demand[size] -= lockers_released  # Update current demand

    # Calculate and accumulate utilization
    for size in ['S', 'M', 'L']:
        # Accumulate period utilization
        if period_key not in period_utilization[size]:
            period_utilization[size][period_key] = 0
        period_utilization[size][period_key] += locker_demand[size]

        # Accumulate yearly utilization
        if year not in yearly_utilization_hours[size]:
            yearly_utilization_hours[size][year] = 0
        yearly_utilization_hours[size][year] += locker_demand[size]

        # Accumulate total utilization hours
        total_utilization_hours[size] += locker_demand[size]

    # Print current hour's locker demand and utilization
    print(f'Current locker demand: S={locker_demand["S"]}, M={locker_demand["M"]}, L={locker_demand["L"]}')

    # Calculate and print hourly utilization
    print('Hourly Utilization:')
    for size in ['S', 'M', 'L']:
        hourly_utilization = locker_demand[size] / locker_capacity[size]
        print(f'  {size}: {hourly_utilization * 100:.2f}%')

    # Move to the next hour
    current_time += timedelta(hours=1)

# Calculate average utilization
average_utilization = {}
for size in ['S', 'M', 'L']:
    average_utilization[size] = total_utilization_hours[size] / (locker_capacity[size] * total_hours)

# Calculate service level
service_level = (total_demands - total_rejects) / total_demands

# Print final results
print("\nMaximum Locker Demand and Corresponding Times:")
print(f"S: {max_locker_demand['S']} at {max_demand_time['S']}, "
      f"M: {max_locker_demand['M']} at {max_demand_time['M']}, "
      f"L: {max_locker_demand['L']} at {max_demand_time['L']}")

print("\nAverage Utilization:")
for size in ['S', 'M', 'L']:
    print(f"{size}: {average_utilization[size]*100:.2f}%")

print(f"\nTotal Demands: {total_demands}")
print(f"Total Rejects: {total_rejects}")
print(f"Service Level: {service_level*100:.2f}%")

# Calculate and print four-month period average utilization and service level
print("\nFour-Month Period Average Utilization and Service Level:")
for period_key in sorted(period_hours.keys()):
    print(f"Period: {period_key[0]} - Quadrimester {period_key[1]}")
    for size in ['S', 'M', 'L']:
        if period_key in period_utilization[size]:
            avg_util = period_utilization[size][period_key] / (locker_capacity[size] * period_hours[period_key])
            print(f"  {size} Average Utilization: {avg_util*100:.2f}%")
    if period_key in period_demands:
        period_demands_count = period_demands[period_key]
        period_rejects_count = period_rejects.get(period_key, 0)
        period_service_level = (period_demands_count - period_rejects_count) / period_demands_count if period_demands_count > 0 else 0
        print(f"  Service Level: {period_service_level*100:.2f}%")

# Calculate and print yearly utilization and rejects per size for 2024 to 2028
print("\nYearly Utilization and Rejects from 2024 to 2028:")
for year in range(2024, 2029):
    if year in yearly_hours:
        print(f"\nYear: {year}")
        for size in ['S', 'M', 'L']:
            if year in yearly_utilization_hours[size]:
                yearly_util = yearly_utilization_hours[size][year] / (locker_capacity[size] * yearly_hours[year])
                print(f"  {size} Average Utilization: {yearly_util*100:.2f}%")
        # Yearly service level
        year_demands = yearly_total_demands.get(year, 0)
        year_rejects = yearly_total_rejects.get(year, 0)
        year_service_level = (year_demands - year_rejects) / year_demands if year_demands > 0 else 0
        print(f"  Service Level: {year_service_level*100:.2f}%")

        # Print rejects per size
        rejects_per_size = yearly_rejects_per_size.get(year, {'S': 0, 'M': 0, 'L': 0})
        print(f"  Rejects per Size: {rejects_per_size}")
