import random

# Define conditional demand scenarios for each year based on the previous year's demand
demand_scenarios = {
    1: {None: [(50000, 0.25), (60000, 0.25), (80000, 0.5)]},  # Initial year
    2: {
        50000: [(60000, 0.3), (65000, 0.4), (70000, 0.3)],
        60000: [(65000, 0.6), (70000, 0.4)],
        80000: [(90000, 0.6), (100000, 0.4)],
    },
    3: {
        60000: [(60000, 0.5), (70000, 0.5)],
        65000: [(60000, 0.3), (70000, 0.4), (75000, 0.3)],
        70000: [(70000, 0.6), (75000, 0.4)],
        90000: [(100000, 0.6), (110000, 0.4)],
        100000:[(100000, 0.4), (110000, 0.6)],
    },
    4: {
        60000: [(60000, 0.5), (75000, 0.5)],
        70000: [(60000, 0.3), (75000, 0.4), (80000, 0.3)],
        75000: [(75000, 0.6), (80000, 0.4)],
        100000: [(80000, 0.1), (105000, 0.6), (120000, 0.3)],
        110000: [(105000, 0.4), (120000, 0.6)],
    },
    5: {
        60000: [(60000, 0.5), (65000, 0.5)],
        75000: [(60000, 0.3), (65000, 0.4), (90000, 0.3)],
        80000: [(65000, 0.6), (90000, 0.4)],
        105000: [(90000, 0.25), (110000, 0.75)],
        120000: [(110000, 0.4), (150000, 0.6)],
    },
}


# Helper function to select demand based on probabilities
def select_demand(scenarios):
    demands, probabilities = zip(*scenarios)
    return random.choices(demands, weights=probabilities, k=1)[0]


# Generate demand for 5 years based on conditional probabilities
def generate_five_year_demand():
    demand = []
    previous_demand = None

    for year in range(1, 6):
        year_scenarios = demand_scenarios[year][previous_demand]
        year_demand = select_demand(year_scenarios)
        demand.append(year_demand)
        previous_demand = year_demand  # Update for the next year's conditional probabilities

    return demand

