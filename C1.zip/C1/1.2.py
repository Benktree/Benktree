#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 27 15:43:49 2025

@author: benktree
"""

import pandas as pd

file_path = "C:/Users/86158/Desktop/郑涵芮的小包裹/European_Countries_and_Capitals.xlsx"

# 加载数据
df_country = pd.read_excel(file_path, sheet_name="Sheet1")
df_city = pd.read_excel(file_path, sheet_name="Sheet2")

# 修正列名，以确保匹配
df_country.columns = df_country.columns.str.strip()
df_city.columns = df_city.columns.str.strip()

# 计算每年每个国家的人口预测
def calculate_population(df, start_col):
    for year in range(2026, 2034):
        df[f'{year}'] = df[start_col] * (1 + df['growth rate'] / 100) ** (year - 2024)
    return df

# 假设“start”是表示2024年人口的列
df_country = calculate_population(df_country, 'start')  # 使用"start"列名
df_city = calculate_population(df_city, 'start')  # 使用"start"列名

# 假设产品类别和型号的需求分配比例（如题目给出）
product_demand_shares = {
    'F10': 0.1, 'K10': 0.05, 'S10': 0.05, 'W10': 0.05, 'L10': 0.04, 'X10': 0.02,
    'F20': 0.04, 'K20': 0.03, 'S20': 0.02, 'W20': 0.02, 'L20': 0.03, 'X20': 0.02,
    'F30': 0.02, 'K30': 0.01, 'S30': 0.01, 'W30': 0.01, 'L30': 0.01, 'X30': 0.01,
    'F50': 0.005, 'K50': 0.005, 'S50': 0.005, 'W50': 0.005, 'L50': 0.005, 'X50': 0.005,
}

# 产品价格（假设示例）
product_prices = {
    'F10': 360, 'K10': 360, 'S10': 360, 'W10': 360, 'L10': 480, 'X10': 480,
    'F20': 480, 'K20': 480, 'S20': 480, 'W20': 480, 'L20': 480, 'X20': 480,
    'F30': 600, 'K30': 600, 'S30': 600, 'W30': 600, 'L30': 600, 'X30': 600,
    'F50': 720, 'K50': 720, 'S50': 720, 'W50': 720, 'L50': 720, 'X50': 720,
}

# 结果列表
results = []

# 为每个国家计算需求量（每年2026-2033年）
for _, row in df_country.iterrows():
    country_name = row['Country']
    
    # 循环每个年份（2026-2033年）
    for year in range(2026, 2034):
        country_demand = row[f'{year}'] * 0.025 / 100  # 以最可能情景为基础
        # 将国家的需求量添加到结果
        for product, share in product_demand_shares.items():
            product_demand = country_demand * share
            product_sales = product_demand * product_prices[product]
            results.append([f"{country_name}", product, product_demand, product_sales, year])

# 为每个城市计算需求量（每年2026-2033年）
for _, city_row in df_city.iterrows():
    city_name = city_row['*Population by citizenship and country of birth - cities and greater cities']
    
    # 循环每个年份（2026-2033年）
    for year in range(2026, 2034):
        city_demand = city_row[f'{year}'] * 0.025 / 100  # 以最可能情景为基础
        # 将城市的需求量添加到结果
        for product, share in product_demand_shares.items():
            product_demand = city_demand * share
            product_sales = product_demand * product_prices[product]
            results.append([f"{city_name}", product, product_demand, product_sales, year])

# 汇总结果为 DataFrame
df_results = pd.DataFrame(results, columns=['Country/City', 'Product', 'Product Demand (Units)', 'Product Sales (€)', 'Year'])

# 将每年需求和销售额作为列
df_pivot = df_results.pivot_table(index=['Country/City', 'Product'], columns='Year', values=['Product Demand (Units)', 'Product Sales (€)'], aggfunc='sum')

# 展示输出文件路径
output_file_path = "C:/Users/86158/Desktop/郑涵芮的小包裹/Calculated_Results_Annual_2026_2033_Expanded.xlsx"

# 导出结果到 Excel 文件
df_pivot.to_excel(output_file_path)

# 打印导出的路径确认
print(f"Results exported to: {output_file_path}")


# -----------------

