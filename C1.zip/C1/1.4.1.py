#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 27 15:50:25 2025

@author: benktree
"""

import pandas as pd
import numpy as np

# 加载数据
file_path = "C:/Users/86158/Desktop/郑涵芮的小包裹/European_Countries_and_Capitals.xlsx"
df_country = pd.read_excel(file_path, sheet_name="Sheet1")
df_city = pd.read_excel(file_path, sheet_name="Sheet2")

# 修正列名，以确保匹配
df_country.columns = df_country.columns.str.strip()
df_city.columns = df_city.columns.str.strip()

# 计算每年每个国家的人口预测
def calculate_population(df, start_col):
    for year in range(2026, 2034):
        df[f'{year}'] = df[start_col] * (1 + df['growth rate'] / 100) ** (year - 2024)
    return df

df_country = calculate_population(df_country, 'start')  # 使用"start"列名
df_city = calculate_population(df_city, 'start')  # 使用"start"列名

# 需求分配比例
product_demand_shares = {
    'F10': 0.1, 'K10': 0.05, 'S10': 0.05, 'W10': 0.05, 'L10': 0.04, 'X10': 0.02,
    'F20': 0.04, 'K20': 0.03, 'S20': 0.02, 'W20': 0.02, 'L20': 0.03, 'X20': 0.02,
    'F30': 0.02, 'K30': 0.01, 'S30': 0.01, 'W30': 0.01, 'L30': 0.01, 'X30': 0.01,
    'F50': 0.005, 'K50': 0.005, 'S50': 0.005, 'W50': 0.005, 'L50': 0.005, 'X50': 0.005,
}

# 产品价格（假设示例）
product_prices = {
    'F10': 360, 'K10': 360, 'S10': 360, 'W10': 360, 'L10': 480, 'X10': 480,
    'F20': 480, 'K20': 480, 'S20': 480, 'W20': 480, 'L20': 480, 'X20': 480,
    'F30': 600, 'K30': 600, 'S30': 600, 'W30': 600, 'L30': 600, 'X30': 600,
    'F50': 720, 'K50': 720, 'S50': 720, 'W50': 720, 'L50': 720, 'X50': 720,
}

# 季节性波动（每月）
seasonal_demand = [0.04, 0.06, 0.06, 0.08, 0.10, 0.14, 0.14, 0.10, 0.08, 0.06, 0.05, 0.05, 0.04]

# 黑五需求占比
black_friday_peak = 0.18  # 黑五至网购周一的需求占全年需求的18%

# 生成场景的函数，批量处理
def generate_demand_scenarios(df_country, df_city, product_demand_shares, seasonal_demand, black_friday_peak, num_scenarios=100):
    scenarios = []
    
    # 国家场景生成
    for _, row in df_country.iterrows():
        country_name = row['Country']
        
        for year in range(2026, 2034):
            country_demand = row[f'{year}'] * 0.025 / 100
            monthly_demand = [country_demand * seasonal for seasonal in seasonal_demand]
            black_friday_demand = country_demand * black_friday_peak
            
            for _ in range(num_scenarios):
                seasonal_fluctuation = np.random.normal(1, 0.2, len(monthly_demand))
                fluctuated_monthly_demand = np.multiply(monthly_demand, seasonal_fluctuation)
                
                weekly_demand = [monthly * 7 / 30 for monthly in fluctuated_monthly_demand]
                daily_demand = [weekly / 7 for weekly in weekly_demand]
                
                for product, share in product_demand_shares.items():
                    product_demand = country_demand * share
                    product_sales = product_demand * product_prices[product]
                    black_friday_sales = black_friday_demand * product_prices[product] * 0.85
                    
                    scenarios.append([country_name, product, product_demand, product_sales, year, fluctuated_monthly_demand, weekly_demand, daily_demand, black_friday_sales])
    
    # 城市场景生成
    for _, city_row in df_city.iterrows():
        city_name = city_row['*Population by citizenship and country of birth - cities and greater cities']
        
        for year in range(2026, 2034):
            city_demand = city_row[f'{year}'] * 0.025 / 100
            monthly_demand = [city_demand * seasonal for seasonal in seasonal_demand]
            black_friday_demand = city_demand * black_friday_peak
            
            for _ in range(num_scenarios):
                seasonal_fluctuation = np.random.normal(1, 0.2, len(monthly_demand))
                fluctuated_monthly_demand = np.multiply(monthly_demand, seasonal_fluctuation)
                
                weekly_demand = [monthly * 7 / 30 for monthly in fluctuated_monthly_demand]
                daily_demand = [weekly / 7 for weekly in weekly_demand]
                
                for product, share in product_demand_shares.items():
                    product_demand = city_demand * share
                    product_sales = product_demand * product_prices[product]
                    black_friday_sales = black_friday_demand * product_prices[product] * 0.85
                    
                    scenarios.append([city_name, product, product_demand, product_sales, year, fluctuated_monthly_demand, weekly_demand, daily_demand, black_friday_sales])
    
    df_scenarios = pd.DataFrame(scenarios, columns=['Country/City', 'Product', 'Product Demand (Units)', 'Product Sales (€)', 'Year', 'Monthly Demand', 'Weekly Demand', 'Daily Demand', 'Black Friday Demand (€)'])
    
    return df_scenarios

# 生成100个替代场景
df_scenarios = generate_demand_scenarios(df_country, df_city, product_demand_shares, seasonal_demand, black_friday_peak, num_scenarios=1000)

# 分批保存多个Excel文件，每个文件包含100个场景
for i in range(0, len(df_scenarios), 1000):
    df_scenarios.iloc[i:i+1000].to_excel(f"C:/Users/86158/Desktop/郑涵芮的小包裹/Daily_Demand_Scenarios_2026_2033_part_{i//1000 + 1}.xlsx", index=False)

# 打印导出的路径确认
print(f"Daily demand scenarios exported successfully!")


# -----------------

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import ast
import os

# 设置文件路径和文件夹路径
folder_path = 'C:/Users/86158/Desktop/郑涵芮的小包裹/'
product = 'F10'  # 你可以替换成其他产品

# 用于存储所有文件的数据
all_data = []

# 遍历文件夹中的文件，从part_1到part_192
for i in range(1, 193):
    file_path = os.path.join(folder_path, f'Daily_Demand_Scenarios_2026_2033_part_{i}.xlsx')
    
    # 检查文件是否存在
    if os.path.exists(file_path):
        df = pd.read_excel(file_path)
        
        # 选择法国的数据
        df_france = df[df['Country/City'] == 'France']
        
        # 筛选出该产品的数据
        df_product = df_france[df_france['Product'] == product]
        
        # 清洗 'Daily Demand' 列，转换字符串类型的列表为实际列表
        def clean_daily_demand(x):
            try:
                return ast.literal_eval(x)  # 将字符串表示的列表转换为列表
            except:
                return None  # 如果无法转换，则返回None

        # 使用 .loc 来确保数据被正确修改
        df_product.loc[:, 'Daily Demand'] = df_product['Daily Demand'].apply(clean_daily_demand)

        # 删除缺失值，只保留'Daily Demand'列中有数据的行
        df_product.loc[:, 'Daily Demand'] = df_product['Daily Demand'].apply(lambda x: sum(x) / len(x) if isinstance(x, list) else x)
        df_product.dropna(subset=['Daily Demand'], inplace=True)

        # 获取年份数据
        df_product.loc[:, 'Year'] = df_product['Year'].astype(int)
        
        # 将筛选出的数据添加到总数据中
        all_data.append(df_product)

# 合并所有数据
df_combined = pd.concat(all_data, ignore_index=True)

# 按年份聚合，计算平均每日需求
df_yearly_demand = df_combined.groupby(['Year']).agg({
    'Daily Demand': 'mean',
    'Product Demand (Units)': 'sum',
    'Product Sales (€)': 'sum'
}).reset_index()

# 1. 绘制年需求趋势图
plt.figure(figsize=(10, 6))
sns.lineplot(x='Year', y='Daily Demand', data=df_yearly_demand, marker='o', color='b')
plt.title(f"Average Daily Demand for {product} in France Across Years (2026-2033)", fontsize=16)
plt.xlabel("Year", fontsize=12)
plt.ylabel("Average Daily Demand", fontsize=12)
plt.grid(True)
plt.show()

# 2. 绘制热图（根据平均每日需求进行绘制）
df_heatmap = df_combined.pivot_table(
    index='Product', 
    columns='Year', 
    values='Daily Demand', 
    aggfunc='mean'
)
plt.figure(figsize=(10, 6))
sns.heatmap(df_heatmap, annot=True, cmap='coolwarm', fmt='.0f', cbar_kws={'label': 'Average Daily Demand'}, linewidths=0.5)
plt.title(f"Heatmap of Average Daily Demand for {product} in France Across Years (2026-2033)", fontsize=16)
plt.xlabel("Year", fontsize=12)
plt.ylabel("Product", fontsize=12)
plt.show()

# 3. 绘制箱形图（展示需求的分布情况）
plt.figure(figsize=(10, 6))
sns.boxplot(x='Year', y='Daily Demand', data=df_combined)
plt.title(f"Boxplot of Daily Demand for {product} in France Across Years (2026-2033)", fontsize=16)
plt.xlabel("Year", fontsize=12)
plt.ylabel("Daily Demand", fontsize=12)
plt.grid(True)
plt.show()

# 4. 绘制柱状图（展示每年每个产品的需求总量）
plt.figure(figsize=(10, 6))
sns.barplot(x='Year', y='Product Demand (Units)', data=df_yearly_demand, color='g')
plt.title(f"Total Product Demand for {product} in France Across Years (2026-2033)", fontsize=16)
plt.xlabel("Year", fontsize=12)
plt.ylabel("Total Product Demand (Units)", fontsize=12)
plt.grid(True)
plt.show()


# -----------------

